"use strict";

var CONFIG = {
  UNIT: "L",
  WATER_COLOR: "#ffca80",
  // red
  WATER_COLOR_SURFACE: "#ffdaa6",
  // pink
  PATTERN_1: {
    // function (fromCup, toCup, litter, fromCupResult, toCupResult, cup1, cup2, cup3)
    steps: {
      0: [1, 2, 7, 3, 7, 10, 0, 0],
      1: [2, 3, 3, 4, 3, 3, 7, 0],
      2: [3, 1, 3, 0, 6, 3, 4, 3],
      3: [2, 3, 3, 1, 3, 6, 4, 0],
      4: [3, 1, 3, 0, 9, 6, 1, 3],
      5: [2, 3, 1, 0, 1, 9, 1, 0],
      6: [1, 2, 7, 2, 7, 9, 0, 1],
      7: [2, 3, 2, 5, 3, 2, 7, 1],
      8: [3, 1, 3, 0, 5, 2, 5, 3]
    },
    current: 0,
    totalStep: 9
  },
  PATTERN_2: {
    // function (fromCup, toCup, litter, fromCupResult, toCupResult, cup1, cup2, cup3)
    steps: {
      0: [1, 3, 3, 7, 3, 10, 0, 0],
      1: [3, 2, 3, 0, 3, 7, 0, 3],
      2: [1, 3, 3, 4, 3, 7, 3, 0],
      3: [3, 2, 3, 0, 6, 4, 3, 3],
      4: [1, 3, 3, 1, 3, 4, 6, 0],
      5: [3, 2, 1, 2, 7, 1, 6, 3],
      6: [2, 1, 7, 0, 8, 1, 7, 2],
      7: [3, 2, 2, 0, 2, 8, 0, 2],
      8: [1, 3, 3, 5, 3, 8, 2, 0],
      9: [3, 2, 3, 0, 5, 5, 2, 3]
    },
    current: 0,
    totalStep: 10
  }
};