"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/* eslint-disable no-restricted-globals */

/* eslint-disable prefer-destructuring */
var JarPool = {
  1: {},
  2: {}
};
var g_dWater = 0.05;
var g_dRotateAngle = 0.5; // const g_dWater = 0.05;
// const g_dRotateAngle = 0.5;

function Jar(origin, grid, id, h, l, pattern) {
  var _this = this;

  this.pattern = pattern;
  var w = 4;
  this.origin = origin || new Point3D(0, 0, 0);
  this.rotateCenter = this.origin;
  this.arrRotateCenter = [];
  this.arrRotateAngle = [];
  this.grid = grid || 1;
  this.id = id;
  this.alpha = 0;
  this.dAlpha = 0;
  this.width = w;
  var waterRatio = 6.6;
  var heighRatio = 7.6;
  this.height = heighRatio * h / 10;
  this.waterLevel = waterRatio * l / 10;

  this.getWalterLevel = function () {
    return _this.waterLevel / waterRatio;
  };

  this.getVolumn = function () {
    return _this.waterLevel / waterRatio * 10;
  };

  this.setVolumn = function (volumn) {
    _this.waterLevel = volumn / 10 * waterRatio;
  };

  this.dx = 0;
  this.X1 = new Point3D(0, 0, 0);
  this.X2 = new Point3D(0, 0, 0);
  this.isFlowing = false;
  this.isPrepareFlowing = false;
  this.currentVolumn = this.getVolumn();
  this.lastVolumn = this.currentVolumn; // this.stopFlowing = false;

  switch (this.id) {
    case "cup-1":
    case "cup-4":
      this.initTranslate = 0;
      break;

    case "cup-2":
    case "cup-5":
      this.initTranslate = 215;
      break;

    case "cup-3":
    case "cup-6":
      this.initTranslate = 430;
      break;

    default:
      this.initTranslate = 0;
      break;
  }

  this.rotateCenterPatterns = [new Point3D(-12.77, -3.6, 0), // 1 cup-1-left
  new Point3D(-8.33, -3.6, 0), // 0 cup-1-right
  new Point3D(-5.6, -1.32, 0), // 2 cup-2-left
  new Point3D(-1.16, -1.32, 0), // 3 cup-2-right
  new Point3D(1.55, 1.9, 0), // 4 cup-3-left
  new Point3D(5.99, 1.9, 0) // 5 cup-3-right
  ];
  var dyTop = 0;

  switch (this.id) {
    case "cup-2":
    case "cup-4":
      dyTop = 0;
      break;

    default:
      break;
  }

  var dx = 0.15;
  this.initVertices = [new Point3D(-w / 2, -this.height + dyTop, 0), new Point3D(-w / 2, 0, 0), new Point3D(w / 2, 0, 0), new Point3D(w / 2, -this.height + dyTop, 0), new Point3D(-w / 2, -this.height + dyTop, 0), // flowLeft
  new Point3D(w / 2, -this.height + dyTop, 0), // flowRight
  new Point3D(-w / 2 - dx, 0, 0), // ellipseBottomLeft
  new Point3D(w / 2 + dx, 0, 0), // ellipseBottomRight
  new Point3D(-w / 2 - dx, -this.height, 0), // left top
  new Point3D(-w / 2 - dx, 0, 0), // left bottom
  new Point3D(w / 2 + dx, -this.height, 0), // right top
  new Point3D(w / 2 + dx, 0, 0) // right bottom
  ];
  this.edges = [[0, 1], [1, 2], [2, 3]];
  this.bottomEdges = [];
  this.surfaceEdges = [];
  this.bottomCurveEdges = [];
  this.surfaceCurveEdges = [];
  this.topCurveEdges = [];
  this.piFlowLeft = 4;
  this.piFlowRight = 5;
  this.piEllipseBottomLeft = 6;
  this.piEllipseBottomRight = 7;
  this.piWhiteLeftTop = 8;
  this.piWhiteLeftBottom = 9;
  this.piWhiteRightTop = 10;
  this.piWhiteRightBottom = 11;
  this.piWaterIntersectBottom = 12;
  this.piFlowOutLeft = 13;
  this.piFlowOutRight = 14;
  this.totalSurfacePoint = 60;
  this.totalBottomPoint = 60;
  this.piStartBE = this.initVertices.length;
  this.piEndBE = this.piStartBE + this.totalBottomPoint - 1;
  this.piStartSP = this.piEndBE + 1;
  this.piEndSP = this.piStartSP + this.totalSurfacePoint - 1;
  this.piStartTopCurve = this.piEndSP + 1;
  this.piEndTopCurve = this.piStartTopCurve + this.totalSurfacePoint / 2;
  this.ellipseBottomA = 60;
  this.ellipseBottomB = 12;

  for (var i = 0; i < this.totalBottomPoint; i++) {
    var p = i * 2 * Math.PI / this.totalBottomPoint;
    var x = this.ellipseBottomA * Math.cos(p) / this.grid;
    var y = this.ellipseBottomB * Math.sin(p) / this.grid + 0.05;
    this.initVertices[this.piStartBE + i] = new Point3D(x, y, 0);

    if (i < this.totalBottomPoint - 1) {
      this.bottomEdges.push([this.piStartBE + i, this.piStartBE + i + 1]);

      if (i < this.totalBottomPoint / 2) {
        this.bottomCurveEdges.push([this.piStartBE + i, this.piStartBE + i + 1]);
      }
    } else {
      this.bottomEdges.push([this.piStartBE + i, this.piStartBE]);
    }
  }

  this.ellipseSurfaceA = 60;
  this.ellipseSurfaceB = 12;
  this.origin2 = new Point3D(-10.55, 3.95, 0);
  this.vertices = this.initVertices.map(function (v) {
    return v.add(_this.origin2);
  });
  this.topCurveCenter = MathLib.getPointByRatio(this.vertices[0], this.vertices[3], 0.5);

  for (var _i = 0; _i < this.totalSurfacePoint; _i++) {
    var _p = _i * 2 * Math.PI / this.totalSurfacePoint;

    var _x = this.ellipseSurfaceA * this.grid / 2 * Math.cos(_p) / this.grid;

    var _y = this.ellipseSurfaceA * this.grid / 2 * Math.sin(_p) / this.grid;

    this.vertices[this.piStartSP + _i] = new Point3D(_x, _y, 0);

    if (_i < this.totalSurfacePoint - 1) {
      this.surfaceEdges[_i] = [this.piStartSP + _i, this.piStartSP + _i + 1];

      if (_i < this.totalSurfacePoint / 2) {
        this.surfaceCurveEdges[_i] = [this.piStartSP + _i, this.piStartSP + _i + 1];
        _x = (this.topCurveCenter.x * this.grid + 64 * Math.cos(_p)) / this.grid;
        _y = (this.topCurveCenter.y * this.grid + 12 * Math.sin(_p)) / this.grid;
        if (_i < this.totalSurfacePoint / 2) this.vertices[this.piStartTopCurve + _i] = new Point3D(_x, _y, 0);
        if (_i < this.totalSurfacePoint / 2 - 1) this.topCurveEdges.push([this.piStartTopCurve + _i, this.piStartTopCurve + _i + 1]);
      }
    } else {
      this.surfaceEdges[_i] = [this.piStartSP + _i, this.piStartSP];
    }
  }

  this.faces = [];
  this.textStyle = {
    fontSize: "18px",
    fill: "#0a83a8",
    "text-anchor": "middle",
    opacity: 0
  };
  this.ratio = 0;
  this.waterLevel2 = 0;
  this.backupFirstData = JSON.parse(JSON.stringify(this));
  this.originVertices = this.vertices.map(function (v) {
    return v.copy();
  });
  setInterval(function () {
    if (g_isStopAnimate[_this.pattern]) return; // if (this.id === "cup-1") console.log(this.id, "ratio", this.ratio);

    if (_this.ratio > 1) {
      var currentVolumn = _this.getVolumn();

      var isReduceSpeed = currentVolumn < 3 && (["cup-1", "cup-4", "cup-3", "cup-6"].indexOf(_this.toCup.id) == -1 || ["cup-3", "cup-6"].indexOf(_this.id) > -1);
      var dWater = currentVolumn < 3 ? g_dWater / 14 : g_dWater;
      var dWaterFillTo = isReduceSpeed ? g_dWater / 4.2 : g_dWater;
      _this.waterLevel -= dWater; // if (this.isPrepareFlowing) this.isFlowing = true;

      if (_this.getVolumn() < _this.lastVolumn) {
        _this.setVolumn(_this.lastVolumn);

        _this.stopFlowing = false;

        _this.toCup.setVolumn(_this.toCup.lastVolumn);
      }

      _this.toCup.waterLevel += dWaterFillTo;

      if (_this.toCup.getVolumn() > _this.toCup.lastVolumn) {
        _this.toCup.setVolumn(_this.toCup.lastVolumn);
      }

      _this.toCup.render("render toCup");

      if (_this.getVolumn() < 0.001) {
        _this.waterLevel = 0;
      }

      _this.render("render filling");
    }
  }, 1);
  this.arrItv = [];
  this.arrSto = [];
}

Jar.prototype.resetDefaultValue = function () {
  var _this2 = this;

  var arrCup = [g_cup1, g_cup2, g_cup3].forEach(function (cup) {
    cup.arrItv.forEach(function (itv) {
      clearInterval(itv);
    });
    cup.arrSto.forEach(function (itv) {
      clearTimeout(itv);
    });
    cup.arrItv = [];
    _this2.arrSto = [];
    var bkData = cup.backupFirstData;
    var bkVertices = bkData.vertices;

    for (var i = 0; i < cup.vertices.length; i++) {
      var v = cup.vertices[i];
      var bkV = bkVertices[i];
      if (!v || !bkV || isNaN(bkV.x) || isNaN(bkV.y) || isNaN(bkV.z)) continue;
      v.paste(bkV);
    }

    cup.rotateCenter = cup.origin;
    cup.arrRotateCenter = [];
    cup.arrRotateAngle = [];
    cup.alpha = 0;
    cup.dAlpha = 0;
    cup.ratio = 0;
    cup.width = bkData.width;
    cup.height = bkData.height;
    cup.waterLevel = bkData.waterLevel;
    cup.dx = bkData.dx;
    cup.X1 = new Point3D(0, 0, 0);
    cup.X2 = new Point3D(0, 0, 0);
    cup.isFlowing = false;
    cup.isPrepareFlowing = false;
    cup.currentVolumn = cup.getVolumn();
    cup.lastVolumn = cup.currentVolumn;
    cup.isMovingDx = false;
    cup.intersectEllipsePoint = null;
    g_isStopAnimate[cup.pattern] = false;
    $(".cup-remain-".concat(cup.id)).attr("opacity", 1);
    $(".".concat(cup.id, "-remain")).text(cup.getVolumn() + CONFIG.UNIT);
    cup.render("render reset");
  });
};

Jar.prototype.rotateX = function (alpha) {
  MathLib.rotate(this, CONST.AXIS.X, alpha);
};

Jar.prototype.rotateY = function (alpha) {
  MathLib.rotate(this, CONST.AXIS.Y, alpha);
};

Jar.prototype.rotateZ = function (alpha) {
  MathLib.rotate(this, CONST.AXIS.Z, alpha);
};

Jar.prototype.rotateAround = function (center) {
  var _this3 = this;

  // if (this.id === "cup-4") console.log(new Date().toISOString(), "star rotateAround");
  var vectorDxDy = new Point3D(_.round(this.dx || 0, 0) / this.grid, _.round(this.dy || 0, 0) / this.grid, 0);
  this.vertices = this.originVertices.map(function (v) {
    return v.add(vectorDxDy);
  });

  var _loop = function _loop(i) {
    var pCenter = _this3.arrRotateCenter[i];
    var angle = i === _this3.arrRotateCenter.length - 1 ? _this3.alpha : _this3.arrRotateAngle[i];

    var vector = _this3.origin.sub(pCenter);

    _this3.vertices = _this3.vertices.map(function (v) {
      return v.add(vector);
    });

    _this3.rotateZ(angle);

    _this3.vertices = _this3.vertices.map(function (v) {
      return v.sub(vector);
    });
  };

  for (var i = 0; i < this.arrRotateCenter.length; i++) {
    _loop(i);
  } // if (this.id === "cup-4") console.log(new Date().toISOString(), "done rotateAround");

};

Jar.prototype.rotateEdge = function (id, id1, id2, alpha) {
  return MathLib.customRotate(this.vertices[id], this.vertices[id1], this.vertices[id2], alpha);
};

Jar.prototype.initDom = function (parentDom) {
  var id = "".concat(this.id);

  if (!$(".".concat(id)).length) {
    this.shapeDom = SVGLib.createTag(CONST.SVG.TAG.GROUP, {
      id: id,
      class: id
    });
    parentDom.append(this.shapeDom);
    return this.shapeDom;
  }

  this.shapeDom = $(".".concat(id, "-origin")).get(0);
  return null;
};

Jar.prototype.isHiddenPoint = function (p, faceArr, pointList) {
  var Q = new Point3D(0, 0, -1000);

  for (var i = 0; i < faceArr.length; i++) {
    var facePoints = [];

    for (var j = 0; j < faceArr[i].length; j++) {
      facePoints.push(pointList[faceArr[i][j]]);
    }

    var output = MathLib.lineIntersectPlan(Q, p, facePoints);
    if (output.isInsideRay && output.isInsidePolygon) return true;
  }

  return false;
};

Jar.prototype.drawPoint = function (p, label, fillColor, showLabel, opacity) {
  var el = $(".".concat(this.id, "-point_").concat(label));

  if (el.length > 0) {
    $(el).attr("cx", (this.origin.x + p.x) * this.grid);
    $(el).attr("cy", (this.origin.y + p.y) * this.grid);
  } else {
    var pointStyle = {
      fill: fillColor,
      stroke: "none",
      opacity: opacity || 0.3
    };
    var r = 0.05;
    var svgPoint = SVGLib.drawCircle(this.origin, p.x, p.y, r, this.grid, pointStyle, "".concat(this.id, "-point_").concat(label));
    this.shapeDom.append(svgPoint);
  }

  if (showLabel) {
    el = $(".".concat(this.id, "-text_").concat(label));

    if (el.length > 0) {
      $(el).text(label);
    } else {
      var svgText = SVGLib.drawText(this.origin, p.x * this.grid, p.y * this.grid, label, this.grid, this.textStyle, "".concat(this.id, "-text_").concat(label));
      this.shapeDom.append(svgText);
    }
  }
};

Jar.prototype.getCenterPoint = function () {
  var _this4 = this;

  var centerPoint = new Point3D(0, 0, 0);
  var vertices = this.vertices.map(function (v) {
    return v.add(_this4.translateSectionVector.multiple(_this4.translateRatio));
  });

  for (var i = 0; i < vertices.length; i++) {
    centerPoint = centerPoint.add(vertices[i]);
  }

  return centerPoint.multiple(1 / vertices.length);
};

Jar.prototype.setRotateCenterRight = function (rotateCenter, alpha) {
  var isPositive = alpha > 0;
  this.rotateCenter = rotateCenter;
  var prevRotate = this.arrRotateCenter[this.arrRotateCenter.length - 1];

  if (!prevRotate) {
    this.arrRotateCenter.push(rotateCenter);
    this.arrRotateAngle.push(Math.abs(alpha));
    this.alpha = isPositive ? 0 : Math.abs(alpha);
  } else if (!prevRotate.equal(rotateCenter)) {
    this.arrRotateCenter.push(rotateCenter);
    this.arrRotateAngle.push(Math.abs(alpha));
    this.alpha = isPositive ? 0 : Math.abs(alpha);
  }
};

Jar.prototype.setRotateCenterLeft = function (rotateCenter, alpha) {
  var isPositive = alpha > 0;
  this.rotateCenter = rotateCenter;
  var prevRotate = this.arrRotateCenter[this.arrRotateCenter.length - 1];

  if (!prevRotate) {
    this.arrRotateCenter.push(rotateCenter);
    this.arrRotateAngle.push(-Math.abs(alpha));
    this.alpha = !isPositive ? this.alpha : -Math.abs(alpha);
  } else if (!prevRotate.equal(rotateCenter)) {
    this.arrRotateCenter.push(rotateCenter);
    this.arrRotateAngle.push(-Math.abs(alpha));
    this.alpha = !isPositive ? 0 : -Math.abs(alpha);
  }
};

var fps = 30;
var uDuraction = 2.5;
var delayTime = 0.2 * 1000;

Jar.prototype.moveDX = function (dx, isMoveLeft, cb) {
  var _this5 = this;

  var self = this;

  var duraction = _.round((Math.abs(dx) > 65 ? 1.5 : 1) * uDuraction, 1); // seconds


  var baseUnit = Math.abs(dx) / (duraction * fps);
  var totalStep = duraction * fps;
  console.log("moveDX", dx, duraction, totalStep, baseUnit);
  var step = 0;
  this.isMovingDX = true;
  var isPositive = dx > 0;
  var unit = (isPositive ? 1 : -1) * baseUnit;
  var count = isPositive ? 0 : Math.abs(dx);
  var vector = new Point3D(unit / self.grid, 0, 0);

  if (isMoveLeft) {
    count = isPositive ? 0 : dx;
    unit = (isPositive ? -1 : 1) * baseUnit;
    vector = new Point3D(unit / self.grid, 0, 0);
  }

  var itvTranslate = setInterval(function () {
    if (g_isStopAnimate[_this5.pattern]) return;
    step++;
    count += unit;

    if (step > totalStep) {
      self.isMovingDX = false;
      clearInterval(itvTranslate);

      _.remove(_this5.arrItv, itvTranslate);

      if (cb) {
        var sto = setTimeout(function () {
          clearTimeout(sto);

          _.remove(_this5.arrSto, sto);

          cb();
        }, delayTime);

        _this5.arrSto.push(sto);
      }

      return;
    }

    self.vertices = self.vertices.map(function (v) {
      return v.add(vector);
    });
    self.dx = count;
    self.render("render moveDx");
  }, duraction / fps);
  this.arrItv.push(itvTranslate);
};

Jar.prototype.moveDY = function (dy, cb) {
  var _this6 = this;

  var self = this;
  var isPositive = dy > 0;
  var count = isPositive ? -dy : 0;

  var duraction = _.round(Math.abs(dy / 100) * uDuraction, 1); // seconds


  var baseUnit = Math.abs(dy) / (duraction * fps);
  var totalStep = duraction * fps;
  var step = 0;
  var unit = (isPositive ? 1 : -1) * baseUnit;
  var vector = new Point3D(0, (isPositive ? 1 : -1) * baseUnit / self.grid, 0);
  var itvTranslate = setInterval(function () {
    if (g_isStopAnimate[_this6.pattern]) return;
    step++;
    count += unit;

    if (step > totalStep) {
      clearInterval(itvTranslate);

      _.remove(_this6.arrItv, itvTranslate);

      if (cb) {
        var sto = setTimeout(function () {
          clearTimeout(sto);

          _.remove(_this6.arrSto, sto);

          cb();
        }, delayTime);

        _this6.arrSto.push(sto);
      }

      return;
    }

    self.vertices = self.vertices.map(function (v) {
      return v.add(vector);
    });
    self.dy = count;
    self.render("render moveDy");
  }, duraction / fps);
  this.arrItv.push(itvTranslate);
};

Jar.prototype.rotateAroundPoint = function (P, alpha, isRotateLeft, isDelayAfterRotate, cb) {
  var _this7 = this;

  var dRotateAngle = g_dRotateAngle; // if (["cup-3", "cup-6"].indexOf(this.id) > -1) {
  //     dRotateAngle = (2 / 3) * g_dRotateAngle;
  // }

  var self = this;

  if (isRotateLeft) {
    self.setRotateCenterLeft(P, alpha);
  } else {
    self.setRotateCenterRight(P, alpha);
  }

  var isPositive = alpha > 0;
  var lastAngle = isPositive ? alpha : 0;
  var angle = isPositive ? 0 : Math.abs(alpha);
  var unit = (isPositive ? 1 : -1) * dRotateAngle;
  var firstAngle = this.alpha;
  var totalStep = Math.ceil(Math.abs(alpha) / Math.abs(unit));
  var step = 0;

  if (isRotateLeft) {
    angle = !isPositive ? 0 : -alpha;
    unit = (!isPositive ? -1 : 1) * dRotateAngle;
    lastAngle = !isPositive ? alpha : 0;
  }

  var stepDelay = 10; // if (["cup-3", "cup-6"].indexOf(this.id) > -1) {
  //     stepDelay = 15;
  // }

  var itvRotate = setInterval(function () {
    if (g_isStopAnimate[self.pattern]) return; // if (self.stopFlowing) {
    //     console.log("self ratio", self.ratio);
    //     return;
    // }
    // if (this.id == "cup-1") console.log("ratio", this.ratio);

    step += 1;
    angle += unit;

    if (step > totalStep || !totalStep) {
      if (!totalStep) console.log("rotateAroundPoint error totalStep", _this7.id, totalStep);
      var diff = Math.abs(alpha) - Math.abs(self.alpha - firstAngle);

      if (Math.abs(diff) > CONST.EPSILON) {
        var ratio = diff / unit;
        self.dAlpha = unit * ratio;
        self.alpha += Math.abs(self.dAlpha) * ratio;
        self.rotateAround(self.rotateCenter, self.dAlpha);
        self.render("render rotateArountPoint diff ".concat(alpha, " ").concat(self.alpha));
      }

      if (cb) {
        var sto = setTimeout(function () {
          clearTimeout(sto);

          _.remove(self.arrSto, sto);

          cb();
        }, isDelayAfterRotate ? delayTime : 0);
        self.arrSto.push(sto);
      }

      _.remove(self.arrItv, itvRotate);

      clearInterval(itvRotate);
      return;
    }

    self.alpha += unit;
    self.rotateAround(self.rotateCenter);
    self.render("render rotateArountPoint");
  }, stepDelay);
  this.arrItv.push(itvRotate);
};

var mapCupDataFillRight = {
  "cup-1": {
    "cup-2": {
      dx: 65,
      checkAngle: 60,
      rotateCenterIdx: 2
    },
    "cup-3": {
      dx: 279.5,
      checkAngle: 30,
      rotateCenterIdx: 4
    }
  },
  "cup-2": {
    "cup-3": {
      dx: 65,
      checkAngle: 30,
      rotateCenterIdx: 4
    }
  },
  "cup-4": {
    "cup-5": {
      dx: 65,
      checkAngle: 60,
      rotateCenterIdx: 2
    },
    "cup-6": {
      dx: 279.5,
      checkAngle: 30,
      rotateCenterIdx: 4
    }
  },
  "cup-5": {
    "cup-6": {
      dx: 65,
      checkAngle: 30,
      rotateCenterIdx: 4
    }
  }
};
var mapCupDataFillLeft = {
  "cup-2": {
    "cup-1": {
      dx: -65,
      dy: -130,
      checkAngle: 66,
      rotateCenterIdx: 1
    }
  },
  "cup-3": {
    "cup-1": {
      dx: -279.5,
      dy: -210,
      checkAngle: 66,
      rotateCenterIdx: 1
    },
    "cup-2": {
      dx: -65,
      dy: -140,
      checkAngle: 66,
      rotateCenterIdx: 3
    }
  },
  "cup-5": {
    "cup-4": {
      dx: -65,
      dy: -130,
      checkAngle: 66,
      rotateCenterIdx: 1
    }
  },
  "cup-6": {
    "cup-4": {
      dx: -279.5,
      dy: -210,
      checkAngle: 66,
      rotateCenterIdx: 1
    },
    "cup-5": {
      dx: -65,
      dy: -140,
      checkAngle: 66,
      rotateCenterIdx: 3
    }
  }
};
var mappingVolumn = {
  "cup-3": {
    0: 89,
    1: 52.6,
    2: 33.3,
    3: 100
  },
  "cup-2": {
    0: 89,
    1: 79.3,
    2: 69.5,
    3: 60.7,
    4: 53.2,
    5: 45.2,
    6: 34.1,
    7: 0
  },
  "cup-1": {
    0: 89,
    1: 82.8,
    2: 78.3,
    3: 73,
    4: 73,
    5: 69.5,
    6: 62.9,
    7: 56.2,
    8: 49.3,
    9: 39.8,
    10: 0
  },
  "cup-6": {
    0: 89,
    1: 52.6,
    2: 33.3,
    3: 100
  },
  "cup-5": {
    0: 89,
    1: 79.3,
    2: 69.5,
    3: 60.7,
    4: 53.2,
    5: 45.2,
    6: 34.1,
    7: 0
  },
  "cup-4": {
    0: 89,
    1: 82.8,
    2: 78.3,
    3: 73,
    4: 73,
    5: 69.5,
    6: 62.9,
    7: 56.2,
    8: 49.3,
    9: 39.8,
    10: 0
  }
};
var g_isPlayingAnimate = {
  1: false,
  2: false
};

Jar.prototype.intersectLineWithCurve = function (p1, p2, curve) {
  var _this8 = this;

  return curve.map(function (e) {
    return MathLib.lineIntersectLine(p1, p2, _this8.vertices[e[0]], _this8.vertices[e[1]]);
  }).filter(function (s) {
    return s && s.ratio2 > 0 && s.ratio2 < 1;
  });
};

Jar.prototype.render = function (msg) {
  var _this9 = this;

  // if (this.id == "cup-4") console.log(new Date().toISOString(), msg);
  var centerJar = MathLib.centerPoint(this.vertices);
  var lineStyle1 = {
    stroke: "blue",
    "stroke-width": "1px"
  };
  var Y1 = new Point3D(0, 10, 0);
  var Y2 = new Point3D(0, -10, 0);
  var el; // ================================================================
  // draw water level
  // case 1

  var i0 = 0;
  var i1 = 1;
  var i2 = 2;
  var i3 = 3;

  var bottomCurve = _.clone(this.bottomCurveEdges);

  if (this.isFlowLeft) {
    i0 = 3;
    i1 = 2;
    i2 = 1;
    i3 = 0;

    _.reverse(bottomCurve);
  }

  var M = MathLib.getPointByRatio(this.vertices[i0], this.vertices[i3], 0.5);
  var N = MathLib.getPointByRatio(this.vertices[i1], this.vertices[i2], 0.5);
  var P = MathLib.getPointByRatio(N, M, this.waterLevel / this.height);
  P.y = Math.max(P.y, this.vertices[i0].y, this.vertices[i3].y);

  var _X1 = new Point3D(-10, P.y, 0);

  var _X2 = new Point3D(10, P.y, 0);

  var X1 = _X1.copy();

  var X2 = _X2.copy();

  var output1 = MathLib.lineIntersectLine(X1, X2, this.vertices[i1], this.vertices[i0]);
  var output2 = MathLib.lineIntersectLine(X1, X2, this.vertices[i2], this.vertices[i3]);
  var output3 = this.intersectLineWithCurve(X1, X2, bottomCurve); // if (this.id === "cup-1") console.log("ratio", [output1.ratio2, output2.ratio2].join(" "));
  //  not intersect with bottom curve

  if (output3.length === 0) {
    if (output1.ratio2 > 0) {
      this.X1 = MathLib.getPointByRatio(this.vertices[i1], this.vertices[i0], output1.ratio2);
    } else {
      this.X1 = this.vertices[i1];
    }
  } else {
    this.X1 = output3[0].intersectPoint;
  }

  if (output2.ratio2 < 1) {
    this.X2 = MathLib.getPointByRatio(this.vertices[i2], this.vertices[i3], output2.ratio2);
    if (!this.isPrepareFlowing) this.isFlowing = false;
    this.ratio = 1;
  } else {
    this.X2 = this.vertices[this.isFlowRight ? this.piFlowRight : this.piFlowLeft];
    this.isFlowing = true;
    this.ratio = 1 + 2 * g_dWater;
  }

  var centerEllipse = MathLib.getPointByRatio(this.X1, this.X2, 0.5);
  var widthEllipse = MathLib.length3D(this.X1, this.X2);
  var waterFlowRightSelector = ".".concat(this.id, " .water-flow-right");
  var waterFlowLeftSelector = ".".concat(this.id, " .water-flow-left");
  var waterFlowSelector = this.isFlowRight ? waterFlowRightSelector : waterFlowLeftSelector;
  this.stopFlowing = false;

  if (isNaN(this.X1.x) || isNaN(this.X1.y) || isNaN(this.X2.x) || isNaN(this.X2.y)) {
    return;
  }

  var faceWater = [];
  var intersectBottoms = this.bottomCurveEdges.map(function (line, idx) {
    return MathLib.lineIntersectLine(_this9.X1, _this9.X2, _this9.vertices[line[0]], _this9.vertices[line[1]]);
  }).filter(function (s) {
    return s;
  });
  var intersectResult = intersectBottoms.filter(function (s) {
    return s.ratio2 > 0 && s.ratio2 < 1;
  });
  var intersectSegment = intersectResult.find(function (x) {
    return x;
  }); // if (intersectSegment) {
  //     const intersectPoint = intersectSegment.intersectPoint;
  //     if (Math.abs(this.X1.x - intersectPoint.x) < 1 && Math.abs(this.X1.y - intersectPoint.y) < 1) {
  //         this.X1 = intersectPoint;
  //     } else if (Math.abs(this.X2.x - intersectPoint.x) < 1 && Math.abs(this.X2.y - intersectPoint.y) < 1) {
  //         this.X2 = intersectPoint;
  //     }
  //     this.intersectEllipsePoint = intersectPoint;
  //     centerEllipse = MathLib.getPointByRatio(this.X1, this.X2, 0.5);
  //     widthEllipse = MathLib.length3D(this.X1, this.X2);
  // } else {
  //     this.intersectEllipsePoint = null;
  // }

  var totalRotate = 0;

  for (var idx = 0; idx < 2; idx++) {
    var rc = this.arrRotateCenter[idx];

    if (rc) {
      var xRotate = rc.x;
      var yRotate = rc.y;
      totalRotate += idx === this.arrRotateAngle.length - 1 ? this.alpha : this.arrRotateAngle[idx];
      var rotate = "rotate(".concat(idx === this.arrRotateCenter.length - 1 ? this.alpha : this.arrRotateAngle[idx], ",").concat(600 + xRotate * this.grid, ",").concat(300 + yRotate * this.grid, ")");
      $(".".concat(this.id, " .rotate-").concat(idx)).attr("transform", rotate);
    } else {
      $(".".concat(this.id, " .rotate-").concat(idx)).removeAttr("transform");
    }
  } // if (output2.ratio2 >= 1) {
  //     this.X2 = this.vertices[this.isFlowRight ? this.piFlowRight : this.piFlowLeft];
  //     centerEllipse = MathLib.getPointByRatio(this.X1, this.X2, 0.5);
  //     widthEllipse = MathLib.length3D(this.X1, this.X2);
  // }
  // if (this.id === "cup-3") {
  //     console.log("totalRotate", totalRotate, this.getVolumn());
  // }
  // update ellipse surface
  // widthEllipse = _.round(widthEllipse, 4);


  var skewX = widthEllipse * this.grid / 120;
  var skewY = 1;

  if (skewY < 1) {
    skewY = skewX;
  }

  if (Math.abs(totalRotate) > 75) {
    skewY = 1 / (1 + Math.abs(75 - Math.abs(totalRotate)) / 5);
  }

  if (skewY > 1) skewY = 1;

  for (var i = 0; i < this.totalSurfacePoint; i++) {
    var p = i * 2 * Math.PI / this.totalSurfacePoint;
    var x = centerEllipse.x + widthEllipse * this.grid / 2 * Math.cos(p) / this.grid;
    var y = centerEllipse.y + this.ellipseSurfaceB * skewY * Math.sin(p) / this.grid;
    this.vertices[this.piStartSP + i] = new Point3D(x, y, 0);

    if (i < this.totalSurfacePoint - 1) {
      this.surfaceEdges[i] = [this.piStartSP + i, this.piStartSP + i + 1];

      if (i < this.totalSurfacePoint / 2) {
        this.surfaceCurveEdges[i] = [this.piStartSP + i, this.piStartSP + i + 1];
      }
    } else {
      this.surfaceEdges[i] = [this.piStartSP + i, this.piStartSP];
    }
  }

  if (intersectResult.length > 0) {
    var idx1 = this.vertices.indexOf(intersectResult[0].Q3);

    if (this.isFlowRight) {
      for (var _i2 = this.bottomCurveEdges[0][0]; _i2 < idx1; _i2++) {
        faceWater.push(this.vertices[_i2]);
      }

      if (output2.ratio2 < 1) faceWater.push(this.X1);
    } else {
      for (var _i3 = idx1; _i3 < this.bottomCurveEdges[this.bottomCurveEdges.length - 1][0]; _i3++) {
        faceWater.push(this.vertices[_i3]);
      }

      if (output2.ratio2 < 1) faceWater.push(this.X2);
    }

    for (var _i4 = this.surfaceCurveEdges.length - 1; _i4 > 0; _i4--) {
      faceWater.push(this.vertices[this.surfaceCurveEdges[_i4][1]]);
    }

    faceWater.push(this.vertices[this.surfaceCurveEdges[0][0]]);
    faceWater.push(this.X2);
  } else {
    for (var _i5 = this.bottomCurveEdges[0][0]; _i5 <= this.bottomCurveEdges[this.bottomCurveEdges.length - 1][1]; _i5++) {
      faceWater.push(this.vertices[_i5]);
    }

    if (output2.ratio2 < 1) {
      if (this.isFlowLeft) {
        faceWater.push(this.X2);
      } else {
        faceWater.push(this.X1);
      }
    }

    for (var _i6 = this.surfaceCurveEdges.length - 1; _i6 > 0; _i6--) {
      faceWater.push(this.vertices[this.surfaceCurveEdges[_i6][1]]);
    }

    if (this.surfaceCurveEdges.length) faceWater.push(this.vertices[this.surfaceCurveEdges[0][0]]);

    if (output2.ratio2 < 1) {
      if (this.isFlowLeft) {
        faceWater.push(this.X1);
      } else {
        faceWater.push(this.X2);
      }
    }
  } // ================================================================


  $(".".concat(this.id, " .translate")).attr("transform", "translate(".concat(this.dx, ", ").concat(this.dy || 0, ")")); // working here

  var faces = [{
    name: "ellipse-surface",
    vertices: [].concat(_toConsumableArray(this.surfaceEdges.map(function (e) {
      return _this9.vertices[e[0]];
    })), [this.vertices[this.surfaceEdges[this.surfaceEdges.length - 1][1]]]),
    cssClass: "cls-5"
  }, {
    name: "water",
    vertices: faceWater,
    cssClass: "cls-4"
  }, {
    name: "left-white",
    vertices: [this.vertices[0], this.vertices[1], this.vertices[this.piEllipseBottomLeft], this.vertices[this.piWhiteLeftTop]],
    cssClass: "cls-white"
  }, {
    name: "right-white",
    vertices: [this.vertices[3], this.vertices[2], this.vertices[this.piEllipseBottomRight], this.vertices[this.piWhiteRightTop]],
    cssClass: "cls-white"
  }];
  faces.forEach(function (f) {
    var faceSelector = "".concat(_this9.id, "-face-").concat(f.name);
    var elface = $(".".concat(faceSelector));

    if (elface.length) {
      var d = SVGLib.getFacePath(_this9.origin, f.vertices, _this9.grid);

      if (d.indexOf("NaN") > -1) {
        elface.removeAttr("d");
      } else elface.attr("d", d);
    } else {
      var svgFace = SVGLib.drawFace(_this9.origin, f.vertices, _this9.grid, {}, faceSelector, f.cssClass);

      if (f.name === "water") {
        $(svgFace).insertBefore(".".concat(_this9.id, " .eclipse-water"));
      } else if (f.name.indexOf("-white") > -1) {
        $(svgFace).insertAfter(".".concat(_this9.id, " .eclipse-water"));
      }
    }
  });
  var currentVolumn = this.getVolumn();
  $(".".concat(this.id, " .eclipse-water, .").concat(this.id, " .eclipse-shape, .").concat(this.id, " .bottom, .").concat(this.id, " .path-water-left, .").concat(this.id, "-face-water")).attr("opacity", currentVolumn < 0.001 ? 0 : 1);
  var edges = [];

  if (this.isShowPoint) {
    [].concat(_toConsumableArray(this.vertices), [this.X1, this.X2]).forEach(function (v, idx) {
      _this9.drawPoint(v, "".concat(_this9.id, "-point-").concat(idx), "blue", false);
    });
  } // if (this.id === "cup-1")
  //     [
  //         this.X1,
  //         this.X2,
  //         output1.intersectPoint,
  //         output2.intersectPoint,
  //         // output3.intersectPoint,
  //         ...this.vertices.filter((v, idx) => idx <= this.piFlowRight),
  //         centerEllipse,
  //     ].forEach((v, idx) => {
  //         if (isNaN(v.x) || isNaN(v.y) || isNaN(v.z)) return;
  //         // eslint-disable-next-line no-nested-ternary
  //         this.drawPoint(v, `tudm-${this.id}-point-${idx}`, idx < 2 ? "red" : idx < 5 ? "green" : "blue", false, 1);
  //     });


  if (this.isShowEdge) {
    edges = [].concat(_toConsumableArray(this.edges), _toConsumableArray(this.bottomEdges), _toConsumableArray(this.surfaceEdges), _toConsumableArray(this.bottomCurveEdges.map(function (l) {
      return [].concat(_toConsumableArray(l), ["green"]);
    })), _toConsumableArray(this.surfaceCurveEdges.map(function (l) {
      return [].concat(_toConsumableArray(l), ["red"]);
    })));
  }

  for (var _i7 = 0; _i7 < edges.length; _i7++) {
    var line = edges[_i7];
    el = $([".".concat(this.id, "-valid_edge"), _i7].join("_"));
    var strokeDashArray = "11, 9";

    if (el.length > 0) {
      var d = SVGLib.getLinePath(this.origin, this.vertices[line[0]], this.vertices[line[1]], this.grid);
      $(el).attr("d", d);
      var strokeLineCap = "round";
      $(el).attr("stroke-linecap", strokeLineCap);
      $(el).attr("opacity", 0.3);
      $(el).attr("stroke-dasharray", strokeDashArray);
    } else {
      var edgeStyle = {
        stroke: line[2] || "gray",
        "stroke-width": "3px",
        "stroke-linejoin": "round",
        "stroke-linecap": "round",
        "stroke-dasharray": strokeDashArray,
        opacity: 1
      };
      var svgLine = SVGLib.drawLine(this.origin, this.vertices[line[0]], this.vertices[line[1]], this.grid, edgeStyle, ["".concat(this.id, "-valid_edge"), _i7].join("_"));
      this.shapeDom.append(svgLine);
    }
  }

  var waterFlowOpacity = !this.isFlowing || !this.isPrepareFlowing || this.getVolumn() < 0.001 ? 0 : 1; //!

  if (waterFlowOpacity && this.toCup) {
    var dist = MathLib.distFromPointToLine(this.isFlowRight ? this.X2 : this.X1, this.toCup.X1, this.toCup.X2) * this.grid - 15.8; // const top = this.vertices[this.isFlowRight ? this.piEndSP - 2 : this.piStartSP + this.totalSurfacePoint / 2 + 2].copy();
    // top.y = this.X2.y;

    var top = this.vertices[this.isFlowRight ? this.piFlowRight : this.piFlowLeft];
    var bottom = top.copy();
    bottom.y += 0.1; // let bottom = this.vertices[this.isFlowRight ? this.piStartSP + 2 : this.piStartSP + this.totalSurfacePoint / 2 - 2];
    // const its = _(
    //     this.topCurveEdges.map((te) =>
    //         this.surfaceCurveEdges.map((se) =>
    //             MathLib.lineIntersectLine(this.vertices[se[0]], this.vertices[se[1]], this.vertices[te[0]], this.vertices[te[1]])
    //         )
    //     )
    // )
    //     .flattenDeep()
    //     .find((s) => s.ratio2 > 0 && s.ratio2 < 1);
    // if (its) bottom = its.intersectPoint;

    var end = {
      x: -(bottom.x - top.x) * this.grid,
      y: -(bottom.y - top.y) * this.grid + 1
    };
    var d2 = "m ".concat(top.x * this.grid, " ").concat(top.y * this.grid, " c 1.72 0.65 24.39 6.64 24.39 15.18 v ").concat(dist, " h -14.27 v ").concat(-(dist + 1), " c 0 -3.6 -5.2 -8.2 ").concat(end.x, " ").concat(end.y, "\n            ");

    if (this.isFlowLeft) {
      d2 = "m ".concat(top.x * this.grid, " ").concat(top.y * this.grid, " c -1.72 0.65 -24.39 6.64 -24.39 15.18 v ").concat(dist, " h 14.27 v ").concat(-(dist + 1), "\n            c 0 -3.6 5.2 -8.2 ").concat(-end.x, " ").concat(end.y, "\n            ");
    }

    $(".".concat(this.id, " .path-flowing")).attr("d", d2);
  }

  $("".concat(waterFlowRightSelector, ", ").concat(waterFlowLeftSelector)).css("opacity", 0);
  $(waterFlowSelector).css("opacity", waterFlowOpacity);
  this.updateVolumnText();
};

Jar.prototype.updateVolumnText = function () {
  var tyTextVolumn = -(MathLib.distFromPointToLine(this.X1, this.vertices[1], this.vertices[2]) * this.grid / 2 - 30);
  var currentVolumn = this.getVolumn();

  if (currentVolumn < 3) {
    tyTextVolumn = -(MathLib.distFromPointToLine(this.vertices[this.piWhiteLeftTop], this.vertices[1], this.vertices[2]) * this.grid / 2 - 30);
  }

  $(".text-volumn-".concat(this.id)).attr("transform", "translate(0,".concat(tyTextVolumn, ")")).attr("opacity", this.getVolumn() > 0 ? 1 : 0);
};

Jar.prototype.fillRight = function (dAngle, toCup, cb) {
  var self = this;
  self.isFlowLeft = false;
  self.isFlowRight = true;
  self.toCup = g_jar[toCup];
  var cupData = mapCupDataFillRight[this.id][toCup];
  var dx = cupData.dx;
  var checkAngle = cupData.checkAngle; // 60 30

  var rotateCenterIdx = cupData.rotateCenterIdx;
  self.moveDX(dx, false, function () {
    var rc1 = self.rotateCenterPatterns[rotateCenterIdx].copy();
    rc1.x -= self.initTranslate / self.grid;
    self.isPrepareFlowing = true;
    self.rotateAroundPoint(rc1, Math.min(dAngle, checkAngle), false, dAngle - checkAngle <= 0, function () {
      var rc2 = self.vertices[3].copy();

      if (dAngle > checkAngle) {
        self.rotateAroundPoint(rc2, dAngle - checkAngle, false, true, function () {
          self.isFlowing = false;
          self.isPrepareFlowing = false;
          self.arrRotateCenter.pop();
          self.arrRotateAngle.pop();
          self.setVolumn(self.lastVolumn);
          self.rotateAroundPoint(rc2, checkAngle - dAngle, false, false, function () {
            self.arrRotateCenter = [];
            self.arrRotateAngle = [];
            self.rotateAroundPoint(rc1, -Math.min(dAngle, checkAngle), false, true, function () {
              self.arrRotateCenter = [];
              self.arrRotateAngle = []; // setTimeout(() => {

              self.moveDX(-dx, false, function () {
                if (cb) cb();
              });
            });
          });
        });
      } else {
        self.arrRotateCenter = [];
        self.arrRotateAngle = [];
        self.isFlowing = false;
        self.isPrepareFlowing = false;
        self.setVolumn(self.lastVolumn);
        self.rotateAroundPoint(rc1, -Math.min(dAngle, checkAngle), false, true, function () {
          self.arrRotateCenter = [];
          self.arrRotateAngle = [];
          self.moveDX(-dx, false, function () {
            if (cb) cb();
          });
        });
      }
    });
  });
};

Jar.prototype.fillLeft = function (dA, toCup, cb) {
  var self = this;
  self.toCup = g_jar[toCup];
  self.isFlowLeft = true;
  self.isFlowRight = false;
  var dAngle = -dA;
  var cupData = mapCupDataFillLeft[self.id][toCup];
  var dx = -cupData.dx;
  var checkAngle = -cupData.checkAngle; // 60 30

  var rotateCenterIdx = cupData.rotateCenterIdx;
  var dy = cupData.dy;
  self.moveDY(dy, function () {
    self.isMovingDx = false;
    self.moveDX(dx, true, function () {
      var rc1 = self.rotateCenterPatterns[rotateCenterIdx].copy();
      rc1.x -= self.initTranslate / self.grid;
      var alpha1 = Math.max(dAngle, checkAngle);
      var alpha2 = dAngle - alpha1;
      self.isPrepareFlowing = true;
      self.rotateAroundPoint(rc1, alpha1, true, dAngle >= checkAngle, function () {
        var rc2 = self.vertices[0].copy();

        if (dAngle < checkAngle) {
          self.rotateAroundPoint(rc2, alpha2, true, true, function () {
            self.arrRotateCenter.pop();
            self.arrRotateAngle.pop();
            self.isFlowing = false;
            self.isPrepareFlowing = false;
            self.setVolumn(self.lastVolumn);
            self.rotateAroundPoint(rc2, -alpha2, true, false, function () {
              self.arrRotateCenter = [];
              self.arrRotateAngle = [];
              self.rotateAroundPoint(rc1, -alpha1, true, true, function () {
                self.arrRotateCenter = [];
                self.arrRotateAngle = [];
                self.isMovingDx = true;
                self.moveDX(-dx, true, function () {
                  self.moveDY(-dy, function () {
                    if (cb) cb();
                  });
                });
              });
            });
          });
        } else {
          self.isFlowing = false;
          self.isPrepareFlowing = false;
          self.arrRotateCenter = [];
          self.arrRotateAngle = [];
          self.setVolumn(self.lastVolumn);
          self.rotateAroundPoint(rc1, -alpha1, true, true, function () {
            self.arrRotateCenter = [];
            self.arrRotateAngle = [];
            self.isMovingDx = true;
            self.moveDX(-dx, true, function () {
              self.moveDY(-dy, function () {
                if (cb) cb();
              });
            });
          });
        }
      });
    });
  });
};

Jar.prototype.fillWaterTo = function (fromCupIdx, toCupIdx, amount, cb) {
  var isFillRight = fromCupIdx < toCupIdx;
  var fromCupId = "cup-".concat(fromCupIdx);
  var toCupId = "cup-".concat(toCupIdx);
  var fromCup = g_jar[fromCupId];
  var toCup = g_jar[toCupId];

  if (g_isPlayingAnimate[fromCup.pattern]) {
    return;
  }

  g_isStopAnimate[fromCup.pattern] = false;
  g_isPlayingAnimate[fromCup.pattern] = true;
  fromCup.lastVolumn = fromCup.getVolumn() - amount;
  toCup.lastVolumn = toCup.getVolumn() + amount;
  var prependElement = {
    "cup-1": ".cup-2-origin",
    "cup-2": ".cup-3-origin",
    "cup-3": ".currentAnimateCup",
    "cup-4": ".cup-5-origin",
    "cup-5": ".cup-6-origin",
    "cup-6": ".currentAnimateCup"
  }[fromCupId];
  var currentVolumn = Math.round(fromCup.getVolumn(), 0);
  var nextVolumn = currentVolumn - amount;
  var rotateAngle = mappingVolumn[fromCupId][nextVolumn];
  $(".cup-remain-".concat(fromCup.id, ", .cup-remain-").concat(toCup.id)).attr("opacity", 0);
  showElement(".cup-curves .cup-curve", false);
  $(".".concat(fromCupId)).not(".cup-curves .".concat(fromCup.id)).detach().appendTo(".currentAnimateCup");
  showElement(".cup-curves .".concat(toCup.id), true);
  if (isFillRight) fromCup.fillRight(rotateAngle, toCup.id, function () {
    $(".".concat(fromCupId)).not(".cup-curves .".concat(fromCup.id)).detach().insertBefore("".concat(prependElement));
    $(".cup-remain-".concat(fromCup.id, ", .cup-remain-").concat(toCup.id)).attr("opacity", 1);
    g_isStopAnimate[fromCup.pattern] = false;
    g_isPlayingAnimate[fromCup.pattern] = false;
    if (cb) cb();
    showElement(".cup-curves .".concat(fromCup.id), false);
  });else fromCup.fillLeft(rotateAngle, toCup.id, function () {
    $(".".concat(fromCupId)).not(".cup-curves .".concat(fromCup.id)).detach().insertBefore("".concat(prependElement));
    $(".cup-remain-".concat(fromCup.id, ", .cup-remain-").concat(toCup.id)).attr("opacity", 1);
    g_isStopAnimate[fromCup.pattern] = false;
    g_isPlayingAnimate[fromCup.pattern] = false;
    if (cb) cb();
    showElement(".cup-curves .".concat(fromCup.id), false);
  });
};

Jar.prototype.stopAnimate = function () {
  console.log("stopAnimate");
  g_isStopAnimate[g_currentPattern] = true;
};

Jar.prototype.continueAnimate = function () {
  console.log("continueAnimate");
  g_isStopAnimate[g_currentPattern] = false;
};

Jar.prototype.goToStepWithData = function (volume) {
  console.log("goToStepWithData", volume);
  var cup = this;
  cup.arrItv.forEach(function (itv) {
    clearInterval(itv);
  });
  cup.arrItv = [];
  this.stopAnimate();
  g_isPlayingAnimate[this.pattern] = false;
  var bkData = cup.backupFirstData;
  var bkVertices = bkData.vertices;

  for (var i = 0; i < cup.vertices.length; i++) {
    var v = cup.vertices[i];
    var bkV = bkVertices[i];
    if (!v || !bkV || isNaN(bkV.x) || isNaN(bkV.y) || isNaN(bkV.z)) continue;
    v.paste(bkV);
  }

  cup.rotateCenter = cup.origin;
  cup.arrRotateCenter = [];
  cup.arrRotateAngle = [];
  cup.alpha = 0;
  cup.dAlpha = 0;
  cup.dx = 0;
  cup.dy = 0;
  cup.currentVolumn = cup.setVolumn(volume);
  cup.lastVolumn = cup.currentVolumn;
  cup.isMovingDx = false;
  cup.intersectEllipsePoint = null;
  g_isStopAnimate[g_currentPattern] = false;
  cup.render("render goToStepWithData");
};

var VERSION = "2020-05-27";