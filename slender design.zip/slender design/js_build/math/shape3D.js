"use strict";

/* eslint-disable no-loop-func */

/* eslint-disable no-redeclare */
function Shape3D(type, origin, grid, id) {
  this.origin = origin || new Point3D(0, 0, 0);
  this.initGrid = grid || 1;
  this.id = id;
  this.rotateLines = [];
  this.lineStyle = {
    opacity: 0
  };
  this.textStyle = {
    fontSize: "18px",
    fill: "#0a83a8",
    "text-anchor": "middle"
  };
  this.angleX = 0;
  this.angleY = 0;
  this.angleZ = 0;
  this.initGrid = grid;
  this.openFaceData = [];
  this.type = type;
  this.isPlaying = false;
  this.translateStep = 0.01;
  this.translateDirection = 1;
  this.translateRatioMin = 0;
  this.translateRatioMax = 1;
  this.translateRatio = this.translateRatioMin;
  this.translateRatioOpacity = 0.7;
  this.translateRatioShowLabel = 0.2;
  this.opacity = 1;
  this.initVertices = [new Point3D(1, -1, 1), new Point3D(-1, -1, 1), new Point3D(-1, -1, -1), new Point3D(1, -1, -1), new Point3D(1, 1, 1), new Point3D(-1, 1, 1), new Point3D(-1, 1, -1), new Point3D(1, 1, -1)];
  this.adjustRatio = 1; // 0.95;

  this.initAngles = [31, 48, 24.2];
  this.graphLines = [];

  switch (type) {
    case CONST.SHAPE_TYPES.CONTENT_01_A:
      this.origin = new Point3D(0, 0, 0);
      this.vertices = [];
      this.initVertices = [];
      this.edges = [];
      this.faces = [];
      this.translateVector = new Point3D(0, 0, 0).sub(this.origin);
      this.graphSolutions = [{
        text: "-2",
        val: -2,
        diff: 0.2
      }, {
        text: "4/3",
        val: 4 / 3,
        diff: 0.2
      }, {
        text: "14/3",
        val: 14 / 3,
        diff: 0.8
      }, {
        text: "0",
        val: 0,
        diff: 0.05
      }, {
        text: "1",
        val: 1,
        diff: 0.05
      }];
      this.graphLines = [{
        name: "line_a",
        a: 1,
        b: 0,
        fx: function fx(x, a, b) {
          return a * x + b * g_coordinateUnit;
        },
        style: {
          fill: "none",
          "stroke-miterlimit": 10,
          stroke: CONFIG.LINE_A_COLOR,
          "stroke-width": CONFIG.LINE_A_STROKE_WIDTH
        }
      }, {
        name: "line_b",
        a: -2,
        b: 10,
        fx: function fx(x, a, b) {
          return a * x + b * g_coordinateUnit;
        },
        style: {
          fill: "none",
          "stroke-miterlimit": 10,
          stroke: CONFIG.LINE_B_COLOR,
          "stroke-width": CONFIG.LINE_B_STROKE_WIDTH
        }
      }, {
        name: "line_c",
        a: 4 / 3,
        b: 5,
        fx: function fx(x, a, b) {
          return a * x + b * g_coordinateUnit;
        },
        style: {
          fill: "none",
          "stroke-miterlimit": 10,
          stroke: CONFIG.LINE_C_COLOR,
          "stroke-width": CONFIG.LINE_C_STROKE_WIDTH
        }
      }];
      break;

    case CONST.SHAPE_TYPES.CONTENT_01_B:
      this.origin = new Point3D(0, 0, 0);
      this.vertices = [];
      this.initVertices = [];
      this.edges = [];
      this.faces = [];
      this.translateVector = new Point3D(0, 0, 0).sub(this.origin);
      this.graphSolutions = [{
        text: "-2",
        val: -2,
        diff: 0.2
      }, {
        text: "-1/4",
        val: -1 / 4,
        diff: 0.1
      }, {
        text: "3",
        val: 3,
        diff: 0.6
      }, {
        text: "0",
        val: 0,
        diff: 0.05
      }, {
        text: "1",
        val: 1,
        diff: 0.05
      }];
      this.graphLines = [{
        name: "line_a",
        a: 1,
        b: 0,
        fx: function fx(x, a, b) {
          return a * x + b * g_coordinateUnit;
        },
        style: {
          fill: "none",
          "stroke-miterlimit": 10,
          stroke: CONFIG.LINE_A_COLOR,
          "stroke-width": CONFIG.LINE_A_STROKE_WIDTH
        }
      }, {
        name: "line_b",
        a: -2,
        b: 5,
        fx: function fx(x, a, b) {
          return a * x + b * g_coordinateUnit;
        },
        style: {
          fill: "none",
          "stroke-miterlimit": 10,
          stroke: CONFIG.LINE_B_COLOR,
          "stroke-width": CONFIG.LINE_B_STROKE_WIDTH
        }
      }, {
        name: "line_c",
        a: -1 / 4,
        b: 13 / 4,
        fx: function fx(x, a, b) {
          return a * x + b * g_coordinateUnit;
        },
        style: {
          fill: "none",
          "stroke-miterlimit": 10,
          stroke: CONFIG.LINE_C_COLOR,
          "stroke-width": CONFIG.LINE_C_STROKE_WIDTH
        }
      }];
      break;
  }

  this.graphLinesDefault = this.graphLines.map(function (g) {
    return JSON.parse(JSON.stringify(g));
  }); // open angles

  this.rotateX(this.initAngles[0]);
  this.rotateY(this.initAngles[1]);
  this.rotateZ(this.initAngles[2]);
}

Shape3D.prototype.rotateX = function (alpha) {
  MathLib.rotate(this, CONST.AXIS.X, alpha);
};

Shape3D.prototype.rotateY = function (alpha) {
  MathLib.rotate(this, CONST.AXIS.Y, alpha);
};

Shape3D.prototype.rotateZ = function (alpha) {
  MathLib.rotate(this, CONST.AXIS.Z, alpha);
};

Shape3D.prototype.rotateEdge = function (id, id1, id2, alpha) {
  var edge = [id1, id2];
  if (indexInArray2(this.rotateLines, edge) == -1) this.rotateLines.push(edge);
  return MathLib.customRotate(this.vertices[id], this.vertices[id1], this.vertices[id2], alpha);
};

Shape3D.prototype.initDom = function (id) {
  this.shapeDom = SVGLib.createTag(CONST.SVG.TAG.GROUP, {
    id: "shape_dom_" + this.id
  });
  this.grid = this.initGrid * this.adjustRatio;
  return this.shapeDom;
};

function indexInArray2(arr, edge) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i][0] == edge[0] && arr[i][1] == edge[1] || arr[i][0] == edge[1] && arr[i][1] == edge[0]) {
      return i;
    }
  }

  return -1;
}

Shape3D.prototype.checkHiddenLine = function (P, Q, faceArrayList, _n) {
  var isPartialVisible = false;
  var isTotalVisible = true;
  var n = _n || 1;

  for (var k = 1; k < n; k++) {
    var M = MathLib.getPointByRatio(P, Q, k / n);
    var isPointVisible = !this.isHiddenPoint(M, faceArrayList);
    if (isPointVisible) isPartialVisible = true;else isTotalVisible = false;
  }

  var isHiddenLine = !isPartialVisible;
  return {
    isHiddenLine: isHiddenLine,
    isTotalVisible: isTotalVisible
  };
};

Shape3D.prototype.getIntersectionLine = function (P, Q, lineArrayList) {
  var ratios = [0, 1];

  for (var i = 0; i < lineArrayList.length; i++) {
    for (var j = 0; j < lineArrayList[i].length; j++) {
      var line = lineArrayList[i][j];
      var P2 = line[0];
      var Q2 = line[1];
      var dP = Math.min(MathLib.length3D(P, P2), MathLib.length3D(P, Q2));
      var dQ = Math.min(MathLib.length3D(Q, P2), MathLib.length3D(Q, Q2));

      if (Math.min(dP, dQ) > CONST.EPSILON) {
        var output = MathLib.lineIntersectLine(P, Q, P2, Q2);
        if (output.intersect && output.ratio > 0 && output.ratio < 1 && output.ratio2 > 0 && output.ratio2 < 1) ratios.push(output.ratio);
      }
    }
  }

  var ratios = ratios.sort(function (a, b) {
    return a - b;
  });
  var ratios2 = [];
  var i = 0;

  while (i < ratios.length - 1) {
    ratios2.push(ratios[i]);
    var j = i + 1;

    while (ratios[j] - ratios[i] < 0.001) {
      j++;
    }

    i = j;
  }

  if (1 - ratios2[ratios2.length - 1] < 0.001) ratios2[ratios2.length - 1] = 1;else ratios2.push(1);
  return ratios2;
};

Shape3D.prototype.isHiddenPoint = function (p, faceArrayList) {
  var Q = new Point3D(0, 0, -1000);

  for (var i = 0; i < faceArrayList.length; i++) {
    for (var j = 0; j < faceArrayList[i].length; j++) {
      var facePoints = faceArrayList[i][j]; // var isInsidePolyon = MathLib.pointInsidePolygon(p, facePoints);

      var isInsidePolyon = true;
      var minZ = 1000;

      for (var k = 0; k < facePoints.length; k++) {
        if (minZ > facePoints[k].z) minZ = facePoints[k].z;
      }

      if (isInsidePolyon && p.z > minZ) {
        var output = MathLib.lineIntersectPlan(Q, p, facePoints);
        if (output.isInsideRay && output.isInsidePolygon) return true;
      }
    }
  }

  return false;
};

Shape3D.prototype.updateData = function () {
  var vertices = $.map(this.vertices, function (v) {
    return v.add(this.translateVector.multiple(this.translateRatio));
  }.bind(this));
  this.grid = this.initGrid * this.adjustRatio;
  var validEdges = [];
  g_faceArrayList[this.id] = []; // g_faceArrayList

  for (var i = 0; i < this.faces.length; i++) {
    var vertexIds = this.faces[i];
    var faceVertices = [];
    var isShowFace = true;

    if (this.type == CONST.SHAPE_TYPES.CUBE_CORE) {
      isShowFace = Math.abs(g_shapes[i + 1].translateRatio - g_shapes[i + 1].translateRatioMin) > CONST.EPSILON;
    } else {
      isShowFace = i > 0 || Math.abs(g_shapes[this.id].translateRatio - g_shapes[this.id].translateRatioMin) > CONST.EPSILON;
    }

    for (var j = 0; j < vertexIds.length; j++) {
      faceVertices.push(vertices[vertexIds[j]]);
    }

    if (isShowFace && this.opacity > 0.01) g_faceArrayList[this.id].push(faceVertices);
  } // get validEdges


  for (var i = 0; i < this.faces.length; i++) {
    var vertexIds = this.faces[i];
    var faceVertices = [];

    for (var j = 0; j < vertexIds.length; j++) {
      var edge = [vertexIds[j], vertexIds[(j + 1) % vertexIds.length]];
      if (indexInArray2(validEdges, edge) == -1 && edge[0] != edge[1]) validEdges.push(edge);
    }
  } // valid edges


  g_edgeArrayList[this.id] = [];

  for (var i = 0; i < validEdges.length; i++) {
    var line = validEdges[i];
    var i1 = line[0];
    var i2 = line[1];
    var isShowLine = true;

    if (this.type == CONST.SHAPE_TYPES.CUBE_CORE) {
      var r1 = Math.abs(g_shapes[1].translateRatio - g_shapes[1].translateRatioMin) < CONST.EPSILON;
      var r2 = Math.abs(g_shapes[2].translateRatio - g_shapes[2].translateRatioMin) < CONST.EPSILON;
      var r3 = Math.abs(g_shapes[3].translateRatio - g_shapes[3].translateRatioMin) < CONST.EPSILON;
      var r4 = Math.abs(g_shapes[4].translateRatio - g_shapes[4].translateRatioMin) < CONST.EPSILON;
      var isStop = [r1, r2, r3, r4];
      var found = false;

      for (var j = 0; j < this.faces.length; j++) {
        if (this.faces[j].indexOf(i1) >= 0 && this.faces[j].indexOf(i2) >= 0 && !isStop[j]) {
          found = true;
        }
      }

      if (!found) isShowLine = false;
    } else if (i1 > 0 && i2 > 0) {
      if (Math.abs(this.translateRatio - this.translateRatioMin) < CONST.EPSILON) isShowLine = false;
    }

    if (isShowLine && this.opacity > 0.01) g_edgeArrayList[this.id].push([vertices[i1], vertices[i2]]);
  }
};

Shape3D.prototype.renderCoordinatePlane = function (colNo, rowNo) {
  if (g_renderCoordinate === 0) {
    g_renderCoordinate = 1; // inprogress

    var columns = colNo || 36;
    var rows = rowNo || 22;
    var colCount = Math.floor(columns / 2);
    var rowCount = Math.floor(rows / 2);
    var unit = 21 / this.grid;
    g_coordinateUnit = unit;
    var xMax = colCount * unit + 10 / this.grid;
    var xMin = -xMax;
    var yMax = rowCount * unit + 10 / this.grid;
    var yMin = -yMax;
    this.coordinate = {
      xMax: xMax,
      yMax: yMax,
      xMin: xMin,
      yMin: yMin
    };
    g_renderCoordinate = 2; // 2 - done
  }
};

var g_svgAnimate = {}; // flag of svg animate

Shape3D.prototype.render = function () {
  this.renderCoordinatePlane();

  if (!g_isRender) {
    g_isRender = true;
    $("#svg_root").css("opacity", 1);
  }

  $("#shape_dom_" + this.id).css("opacity", this.opacity);
  $("#group-label-" + this.id).css("opacity", this.opacity);
  $(".shape-element-" + this.id).css("opacity", this.opacity);
  var vertices = $.map(this.vertices, function (v) {
    return v.add(this.translateVector.multiple(this.translateRatio));
  }.bind(this));
  this.grid = this.initGrid * this.adjustRatio; // draw graphLines

  var xMax = this.coordinate.xMax;
  var yMax = this.coordinate.yMax;
  var xMin = this.coordinate.xMin;
  var yMin = this.coordinate.yMin;
  var lines = []; // 4 coordinate edges

  var coordinatePoints = [new Point3D(xMin, yMin, 0), new Point3D(xMax, yMin, 0), new Point3D(xMax, yMax, 0), new Point3D(xMin, yMax, 0)]; // var isChangeWithDefault = false;

  for (var i = 0; i < this.graphLines.length; i++) {
    var graph = this.graphLines[i]; // if (!isChangeWithDefault) {
    //     var g = [graph.a, graph.b];
    //     var gd = [this.graphLinesDefault[i].a, this.graphLinesDefault[i].b];
    //     isChangeWithDefault = _(g)
    //         .map(function (x, idx) {
    //             return Math.abs(x - gd[idx]);
    //         })
    //         .some(function (x) {
    //             return x > 0.05;
    //         });
    // }

    if (graph.isRendered && !graph.needToRender) continue;
    var fx = graph.fx;
    var p1 = graph.isOy ? new Point3D(0, yMin, 0) : new Point3D(xMin, -fx(xMin, graph.a, graph.b), 0);
    var p2 = graph.isOy ? new Point3D(0, yMax, 0) : new Point3D(xMax, -fx(xMax, graph.a, graph.b), 0);
    var intersectPoints = [];

    for (var j = 0; j < coordinatePoints.length; j++) {
      var p = coordinatePoints[j];
      var result = MathLib.lineIntersectLine(p1, p2, p, coordinatePoints[(j + 1) % coordinatePoints.length]);

      if (result.intersect) {
        if (result.ratio2 <= 1 + CONST.EPSILON && result.ratio2 >= 0) {
          intersectPoints.push(result.intersectPoint);
          if (intersectPoints.length === 2) break;
        }
      }
    }

    lines.push({
      p1: intersectPoints[0],
      p2: intersectPoints[1],
      style: graph.style,
      name: graph.name,
      isDragging: graph.isDragging
    }); // $(".text_line_a_x").attr("transform", "translate(390 588.41)");

    graph.points = [intersectPoints[0], intersectPoints[1]];
    graph.needToRender = false;
    if (!graph.isRendered) graph.isRendered = true;
  }

  var graphSegments = this.graphLines.map(function (grp) {
    return grp.points;
  }); // triangle-color

  var trianglePoints = [];
  graphSegments.forEach(function (segment, idx) {
    var nextSegment = graphSegments[(idx + 1) % graphSegments.length];
    var intersectResult = MathLib.lineIntersectLine(segment[0], segment[1], nextSegment[0], nextSegment[1]);

    if (intersectResult.intersectPoint) {
      if (intersectResult.intersectPoint.x > xMax || intersectResult.intersectPoint.x < xMin || intersectResult.intersectPoint.y < yMin || intersectResult.intersectPoint.y > yMax) {
        var points = _([segment[0], segment[1], nextSegment[0], nextSegment[1]]).map(function (v) {
          v.length = MathLib.lengthXY(intersectResult.intersectPoint, v);
          return v;
        }).sortBy("length").value();

        trianglePoints.push(points[0]);
        trianglePoints.push(points[1]);
      } else {
        trianglePoints.push(intersectResult.intersectPoint);
      }
    }
  });
  trianglePoints = MathLib.sortPolygonPoints(trianglePoints);

  if ($("#triangle-color").length) {
    $("#triangle-color").attr("d", SVGLib.getFacePath(this.origin, trianglePoints, this.grid));
  } else {
    this.shapeDom.append(SVGLib.drawFace(this.origin, trianglePoints, this.grid, {
      fill: "#fff3b8"
    }, "triangle-color"));
  }

  showElement(".text_CONTENT_01_B, .text_CONTENT_01_A", false);
  showElement(".text_" + g_pattern, true);

  if (!g_buttonAnimateInterval["#button-reset-active"]) {
    showElement("#button-reset-active, #button-reset-inactive, #button-reset-disable", false);
    showElement(g_isChangeWithDefault ? "#button-reset-active, #button-reset-inactive" : "#button-reset-disable", true);
  }

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    var lId = ["graph", line.name].join("_");
    var lineDOM = $("#" + lId);

    if (!lineDOM.length) {
      var svgLine = SVGLib.drawLine(this.origin, line.p1, line.p2, this.grid, line.style, lId);
      this.shapeDom.append(svgLine);
    } else {
      var d = SVGLib.getLinePath(this.origin, line.p1, line.p2, this.grid);
      $(lineDOM).attr("d", d);

      if (line.isDragging) {
        if (!g_svgAnimate[lId]) {
          g_svgAnimate[lId] = animateStroke("#" + lId, 0.5, 6, 0.2, 1);
        }
      } else {
        $(lineDOM).attr("opacity", 1);
        clearInterval(g_svgAnimate[lId]);
        delete g_svgAnimate[lId];
      }
    }
  }
};

function animateStroke(selector, duraction, changeTimeInSec, minOpacity, maxOpacity) {
  var totalTime = changeTimeInSec || 5;
  var min = minOpacity || 0.2;
  var max = maxOpacity || 1;
  var dO = (max - min) / totalTime;
  var opacity = min;
  var direct = 1;
  return setInterval(function () {
    if (opacity < min - dO || opacity > max - dO) {
      direct = direct * -1;
    }

    opacity += direct * dO;
    $(selector).attr("opacity", opacity);
  }, duraction * 1000 / totalTime);
}