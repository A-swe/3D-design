"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }


var g_shapes = [];
var g_shape;
var g_buttonAnimateInterval = {};
var g_isAnimatingButton = false; // var g_buttonStates = [false, false, false, false];

var g_isShowLog = false;
var g_isShowVertexId = false;
var g_layoutWidth = 1024;
var g_layoutHeight = 648;
var g_isRender = false;
var g_isRotated = false;
var g_latestMousePress = "";
var g_faceArrayList = [];
var g_edgeArrayList = [];
var g_msgLog = "";
var g_browserLog = "";
var g_startTime;
var g_endTime;
var g_disableReload = true;
var g_isStartGame = false;
var g_interval;
var g_framePerSecond = getFrameRate();
var g_numberOfFrames = getNumberOfFrames();
var g_dragablePosition = {}; // store initial dragable area position

var g_renderCoordinate = 0; // 0 - none, 1 - inprogress, 2 - done

var g_coordinateUnit = 0.2;
var g_isChangeWithDefault = false;
var g_radioPatternChoosed = 1;
var g_currentStep = 0;
var g_currentPattern = 1;
var g_isDisabledBtn1 = {
  1: true,
  2: true
};
var g_isDisabledBtn2 = {
  1: true,
  2: true
};
var g_isDisabledBtn3 = {
  1: false,
  2: false
};
var g_isDisabledBtn4 = {
  1: true,
  2: true
};
var g_selectedButton;
var g_isChanged = false;
var g_isStopAnimate = {
  1: false,
  2: false
}; // ---------------------------------------------------------

window.addEventListener("touchmove", function (ev) {
  ev.preventDefault ? ev.preventDefault() : ev.returnValue = false;
}, {
  passive: false
});
window.addEventListener("mousemove", function (ev) {
  ev.preventDefault ? ev.preventDefault() : ev.returnValue = false;
}); // ---------------------------------------------------------

var Draw = {
  setting: {
    svgDom: $("#svg"),
    grid: 30
  },
  init: function init() {
    var transform = SVGLib.getStrMatrix(1, 0, 0, 1, 600, 300);
    var idSvg = "demo_shape";
    var svg = $("#".concat(idSvg));

    if (!svg) {
      this.shapeGroup = SVGLib.createTag(CONST.SVG.TAG.GROUP, {
        id: "demo_shape",
        transform: transform
      });
      this.setting.svgDom.append(this.shapeGroup);
    } else {
      $("#".concat(idSvg)).attr("transform", transform);
      this.shapeGroup = document.getElementById(idSvg);
    } // this.rotateEvent(".draggable-zone");

  },
  rotateEvent: function rotateEvent(element) {
    var prevX = 0;
    var prevY = 0;
    var svg = document.querySelector("svg"); // Create an SVGPoint for future math

    var pt = svg.createSVGPoint();

    function cursorPoint(evt) {
      var c = /Edge/.test(window.navigator.userAgent) ? document.getElementById("graph_line_a") : svg;
      pt.x = evt.clientX;
      pt.y = evt.clientY;
      var ctm = c.getScreenCTM();
      var inverse = ctm.inverse();
      var p = pt.matrixTransform(inverse);
      return {
        x: p.x,
        y: p.y
      };
    }

    $(element).draggable({
      start: function start(event, ui) {
        prevX = event.clientX;
        prevY = event.clientY;
        event.stopPropagation();
        $(".text-hint").fadeOut(500);
      },
      drag: function drag(event, ui) {
        // const layoutLoc = SVGLib.getTranslate("#cup-1");
        // const curPos = cursorPoint(event);
        // const x = curPos.x - layoutLoc.left; // / Draw.setting.grid;
        // const y = curPos.y - layoutLoc.top; // / Draw.setting.grid;
        // console.log(`new Point3D(${(x - 600) / Draw.setting.grid}, ${(y - 300) / Draw.setting.grid}, 0)`);
        // $("#tudm").attr("cx", x).attr("cy", y);
        var x = event.clientX;
        var y = event.clientY;
        var dx = x - prevX;
        var dy = y - prevY;
        var ratio = 1;
        var angle = dy * ratio;
        g_shape.dAlpha = angle;
        g_shape.alpha += angle; // eslint-disable-next-line prefer-destructuring

        g_shape.rotateCenter = g_shape.rotateCenterPatterns[1];
        g_shape.rotateAround(g_shape.rotateCenter, g_shape.dAlpha);
        g_shape.render();
        prevX = x;
        prevY = y;
        event.stopPropagation();
      }
    });
  }
};

function init() {
  // buttons-1
  showPatternButton(".history-buttons", true);
  disabledButton("history", true); // buttons-2

  showPatternButton(".back-buttons", true);
  disabledButton("back", true); // buttons-3

  showPatternButton(".play-buttons", true);
  enabledButton("play", true);
  showPatternButton(".pause-buttons", false);
  hiddenButton("pause", true);
  showPatternButton(".resume-buttons", false);
  hiddenButton("resume", true);
  showPatternButton(".next-buttons", false);
  hiddenButton("next", true);
  $(".buttons-3").addClass("btn-pointer"); // buttons-4

  showPatternButton(".reload-buttons", true);
  disabledButton("reload", true); // select pattern

  showElement(".radio-1 .active", true);
  showElement(".radio-2 .active", false);
}

function showPatternButton(btnSelector, isShow) {
  showElement("".concat(btnSelector), false);
  showElement(".pattern-".concat(g_currentPattern, " ").concat(btnSelector), isShow);
}

function disabledButton(btnName, isForAllPattern) {
  var prefixSelector = isForAllPattern ? "" : ".pattern-".concat(g_currentPattern, " ");
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-disabled"), true);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-active"), false);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-inactive"), false);
}

function enabledButton(btnName, isForAllPattern) {
  var prefixSelector = isForAllPattern ? "" : ".pattern-".concat(g_currentPattern, " ");
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-disabled"), false);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-active"), false);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-inactive"), true);
}

function activeButton(btnName, isForAllPattern) {
  var prefixSelector = isForAllPattern ? "" : ".pattern-".concat(g_currentPattern, " ");
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-disabled"), false);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-active"), true);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-inactive"), false);
}

function hiddenButton(btnName, isForAllPattern) {
  var prefixSelector = isForAllPattern ? "" : ".pattern-".concat(g_currentPattern, " ");
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-disabled"), false);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-active"), false);
  showElement("".concat(prefixSelector, ".btn-").concat(btnName, "-inactive"), false);
}

function showElement(element, visible) {
  $(element).css("visibility", visible ? "visible" : "hidden");
}

function translateDxDy(selector, dx, dy) {
  var els = $(selector);

  var _loop = function _loop(i) {
    var el = els[i];
    var matrix = $(el).attr("transform");

    if (!matrix || matrix === "none") {
      matrix = $(el).css("transform");
    }

    matrix = matrix.replace(/[^0-9\s\-.,]/g, "").split(/[\s,]/).filter(function (x) {
      return x !== "";
    }).map(function (m) {
      return Number(m);
    });

    if (matrix.length === 1) {
      matrix = [1, 0, 0, 1, 0, 0];
    }

    var x = matrix[12] || matrix[4] || matrix[0];
    var y = matrix[13] || matrix[5] || matrix[1]; // cache origin transform x, y

    if ($(el).attr("origin-matrix-x") === undefined) {
      $(el).attr("origin-matrix-x", x);
    }

    if ($(el).attr("origin-matrix-y") === undefined) {
      $(el).attr("origin-matrix-y", y);
    } // update transform x


    [12, 4].forEach(function (m) {
      if (matrix[m] !== undefined) {
        matrix[m] += dx || 0;
      }
    }); // update transform y

    [13, 5].forEach(function (m) {
      if (matrix[m] !== undefined) {
        matrix[m] += dy || 0;
      }
    });
    $(el).css("transform", "matrix(".concat(matrix.join(","), ")"));
    $(el).attr("transform", "matrix(".concat(matrix.join(","), ")"));
  };

  for (var i = 0; i < els.length; i++) {
    _loop(i);
  }
}

function resetTranslateOrigin(selector) {
  var els = $(selector);

  var _loop2 = function _loop2(i) {
    var el = els[i];
    var matrix = $(el).attr("transform");

    if (!matrix || matrix === "none") {
      matrix = $(el).css("transform");
    }

    matrix = matrix.replace(/[^0-9\s\-.,]/g, "").split(/[\s,]/).filter(function (x) {
      return x !== "";
    }).map(function (m) {
      return Number(m);
    });

    if (matrix.length === 1) {
      matrix = [1, 0, 0, 1, 0, 0];
    } else if (matrix.length === 2) {
      matrix = [1, 0, 0, 1].concat(_toConsumableArray(matrix));
    }

    var x = matrix[12] || matrix[4] || matrix[0];
    var y = matrix[13] || matrix[5] || matrix[1]; // get origin transform x, y

    if ($(el).attr("origin-matrix-x") !== undefined) {
      var dx = Number($(el).attr("origin-matrix-x"));
      [12, 4].forEach(function (m) {
        if (matrix[m] !== undefined) {
          matrix[m] = Number(dx);
        }
      });
    }

    if ($(el).attr("origin-matrix-y") !== undefined) {
      var dy = Number($(el).attr("origin-matrix-y"));
      [13, 5].forEach(function (m) {
        if (matrix[m] !== undefined) {
          matrix[m] = Number(dy);
        }
      });
    }

    var matrixText = "matrix(".concat(matrix.join(","), ")");
    $(el).css("transform", matrixText).attr("transform", matrixText);
  };

  for (var i = 0; i < els.length; i++) {
    _loop2(i);
  }
}

function minifyNumber(str) {
  var n = 2;
  var p = Math.pow(10, n);
  var str2 = str;
  var i = 0;

  while (i < str.length) {
    if (str[i] == ".") {
      var j = i - 1;

      while (j >= 0 && str[j] >= "0" && str[j] <= "9") {
        j--;
      }

      var k = i + 1;

      while (k < str.length && str[k] >= "0" && str[k] <= "9") {
        k++;
      }

      var s = str.substring(j + 1, k);
      var x = Math.round(parseFloat(s) * p) / p;
      str2 = str2.replace(s, x.toString());
      i = k;
    } else {
      i++;
    }
  }

  return str2;
}

function writeLog() {
  $("#text-log").text(g_msgLog);
}

function keepDraggableSvgNotMove() {
  if (g_dragablePosition.top === undefined) {
    g_dragablePosition.top = parseInt($(".draggable-zone").css("top"), 10);
    g_dragablePosition.left = parseInt($(".draggable-zone").css("left"), 10);
  } else {
    setTimeout(function () {
      $(".draggable-zone").css("top", g_dragablePosition.top);
      $(".draggable-zone").css("left", g_dragablePosition.left);
    }, 50);
  }
}

function animateButtonEffect(sid, isDown, cb) {
  if (g_buttonAnimateInterval[sid]) clearInterval(g_buttonAnimateInterval[sid]);
  var self = $(sid);
  var duration = 200;
  var nFrame = 10;
  var dy1 = isDown ? 0 : 4;
  var dy2 = isDown ? 4 : 0;
  var ddy = (dy2 - dy1) / nFrame;
  g_buttonAnimateInterval[sid] = setInterval(function () {
    dy1 += ddy;
    self.attr("transform", SVGLib.getStrMatrix(1, 0, 0, 1, 0, dy1));

    if (Math.abs(dy1 - dy2) < CONST.EPSILON) {
      clearInterval(g_buttonAnimateInterval[sid]);
      if (cb) cb();
      g_isAnimatingButton = false;
    }
  }, duration / nFrame);
}

function initShapes() {
  $(".shape-element-0").remove(); // g_shape = new Shape3D(CONST.SHAPE_TYPES[g_pattern], Draw.setting.origin, Draw.setting.grid, 0);
  // Draw.appendToShapeGroup(g_shape.initDom());
  // g_shape.render();

  keepDraggableSvgNotMove();
}

var loadConfig = function loadConfig() {
  $(".unit").text(CONFIG.UNIT);
  $("#svg .cls-4").css("fill", CONFIG.WATER_COLOR); // water

  $("#svg .cls-5").css("fill", CONFIG.WATER_COLOR_SURFACE); // surface
};

var loadStaticSVG = function loadStaticSVG() {
  var hardCodeSufix = '<script type="text/javascript">\n                        //      <![CDATA[  <-- For SVG support\n                        //          ]]>\n                        </script></svg>'; // buttons

  $(".radio-1").prepend(CONFIG_SVG.radio_button_1.replace("</svg>"));
  $(".radio-2").prepend(CONFIG_SVG.radio_button_2.replace("</svg>"));
  $(".history-buttons").prepend(CONFIG_SVG.history_buttons.replace("</svg>"));
  $(".back-buttons").prepend(CONFIG_SVG.back_buttons.replace("</svg>"));
  $(".play-buttons").prepend(CONFIG_SVG.play_buttons.replace("</svg>"));
  $(".pause-buttons").prepend(CONFIG_SVG.pause_buttons.replace("</svg>"));
  $(".resume-buttons").prepend(CONFIG_SVG.resume_buttons.replace("</svg>"));
  $(".next-buttons").prepend(CONFIG_SVG.next_buttons.replace("</svg>"));
  $(".reload-buttons").prepend(CONFIG_SVG.reload_buttons.replace("</svg>")); 

  $(".pattern-01-history #step-0").prepend(CONFIG_SVG.pattern1_step0.replace("</svg>"));
  $(".pattern-01-history #step-1").prepend(CONFIG_SVG.pattern1_step1.replace("</svg>"));
  $(".pattern-01-history #step-2").prepend(CONFIG_SVG.pattern1_step2.replace("</svg>"));
  $(".pattern-01-history #step-3").prepend(CONFIG_SVG.pattern1_step3.replace("</svg>"));
  $(".pattern-01-history #step-4").prepend(CONFIG_SVG.pattern1_step4.replace("</svg>"));
  $(".pattern-01-history #step-5").prepend(CONFIG_SVG.pattern1_step5.replace("</svg>"));
  $(".pattern-01-history #step-6").prepend(CONFIG_SVG.pattern1_step6.replace("</svg>"));
  $(".pattern-01-history #step-7").prepend(CONFIG_SVG.pattern1_step7.replace("</svg>"));
  $(".pattern-01-history #step-8").prepend(CONFIG_SVG.pattern1_step8.replace("</svg>"));
  $(".pattern-01-history #step-9").prepend(CONFIG_SVG.pattern1_step9.replace("</svg>"));

  $(".pattern-02-history #step-0").prepend(CONFIG_SVG.pattern2_step0.replace("</svg>"));
  $(".pattern-02-history #step-1").prepend(CONFIG_SVG.pattern2_step1.replace("</svg>"));
  $(".pattern-02-history #step-2").prepend(CONFIG_SVG.pattern2_step2.replace("</svg>"));
  $(".pattern-02-history #step-3").prepend(CONFIG_SVG.pattern2_step3.replace("</svg>"));
  $(".pattern-02-history #step-4").prepend(CONFIG_SVG.pattern2_step4.replace("</svg>"));
  $(".pattern-02-history #step-5").prepend(CONFIG_SVG.pattern2_step5.replace("</svg>"));
  $(".pattern-02-history #step-6").prepend(CONFIG_SVG.pattern2_step6.replace("</svg>"));
  $(".pattern-02-history #step-7").prepend(CONFIG_SVG.pattern2_step7.replace("</svg>"));
  $(".pattern-02-history #step-8").prepend(CONFIG_SVG.pattern2_step8.replace("</svg>"));
  $(".pattern-02-history #step-9").prepend(CONFIG_SVG.pattern2_step9.replace("</svg>"));
  $(".pattern-02-history #step-10").prepend(CONFIG_SVG.pattern2_step10.replace("</svg>"));
};

function backToStep(step) {
  var patterns;

  if (g_currentPattern === 1) {
    patterns = CONFIG.PATTERN_1;
  } else {
    patterns = CONFIG.PATTERN_2;
  }

  g_cup1.resetDefaultValue();
  g_cup2.resetDefaultValue();
  g_cup3.resetDefaultValue();

  if (step >= patterns.totalStep) {
    $(".".concat(g_cup1.id, "-remain")).text(5 + CONFIG.UNIT);
    $(".".concat(g_cup2.id, "-remain")).text(5 + CONFIG.UNIT);
    $(".".concat(g_cup3.id, "-remain")).text(0 + CONFIG.UNIT);
    g_cup1.goToStepWithData(5);
    g_cup2.goToStepWithData(5);
    g_cup3.goToStepWithData(0);
    patterns.current = step;
  } else {
    var action = patterns.steps[step];
    $(".".concat(g_cup1.id, "-remain")).text(action[5] + CONFIG.UNIT);
    $(".".concat(g_cup2.id, "-remain")).text(action[6] + CONFIG.UNIT);
    $(".".concat(g_cup3.id, "-remain")).text(action[7] + CONFIG.UNIT);
    g_cup1.goToStepWithData(action[5]);
    g_cup2.goToStepWithData(action[6]);
    g_cup3.goToStepWithData(action[7]);
    patterns.current = step;
    updateDescription(action, step);
  }

  if (step === 0) {
    // trạng thái ban đầu
    disabledButton("history");
    $(".buttons-1").removeClass("btn-pointer");
    g_isDisabledBtn1[g_currentPattern] = true;
    disabledButton("back");
    $(".buttons-2").removeClass("btn-pointer");
    g_isDisabledBtn2[g_currentPattern] = true;
    hiddenButton("pause");
    hiddenButton("resume");
    hiddenButton("next");
    enabledButton("play");
    $(".buttons-3").addClass("btn-pointer");
    g_isDisabledBtn3[g_currentPattern] = false;
    disabledButton("reload");
    $(".buttons-4").removeClass("btn-pointer");
    g_isDisabledBtn4[g_currentPattern] = true;
  } else if (step >= patterns.totalStep) {
    // trạng thái kết thúc
    enabledButton("history");
    $("#buttons-1").addClass("btn-pointer");
    g_isDisabledBtn1[g_currentPattern] = false;
    enabledButton("back");
    $("#buttons-2").addClass("btn-pointer");
    g_isDisabledBtn2[g_currentPattern] = false;
    hiddenButton("pause");
    hiddenButton("resume");
    hiddenButton("play");
    disabledButton("next");
    $(".buttons-3").removeClass("btn-pointer");
    g_isDisabledBtn3[g_currentPattern] = true;
  } else {
    // trạng thái giữa
    enabledButton("history");
    $(".buttons-1").addClass("btn-pointer");
    g_isDisabledBtn1[g_currentPattern] = false;
    enabledButton("back");
    $(".buttons-2").addClass("btn-pointer");
    g_isDisabledBtn2[g_currentPattern] = false;
    hiddenButton("pause");
    hiddenButton("resume");
    hiddenButton("play");
    enabledButton("next");
    $(".buttons-3").addClass("btn-pointer");
    g_isDisabledBtn3[g_currentPattern] = false;
    enabledButton("reload");
    $(".buttons-4").addClass("btn-pointer");
    g_isDisabledBtn4[g_currentPattern] = false;
  }
}

var cupMapping = {
  1: "10L",
  2: "7L",
  3: "3L"
};
var descriptionStep = ["①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩", "⑪", "⑫", "⑬", "⑭", "⑮", "⑯", "⑰", "⑱", "⑲", "⑳"];

function updateDescription(action, step) {
  $(".play-step-description.pattern-".concat(g_currentPattern, " .content")).text("".concat(descriptionStep[step], " ").concat(cupMapping[action[0]], " From the cup ").concat(cupMapping[action[1]], "Liquid in the cup ").concat(action[2], "L Move"));
}

function playStep(step) {
  var pattern = g_currentPattern;
  console.log("playStep", step);
  var patterns;

  if (g_currentPattern === 1) {
    patterns = CONFIG.PATTERN_1;
  } else {
    patterns = CONFIG.PATTERN_2;
  }

  var action = patterns.steps[step];
  if (!action) return;
  $(".play-step-description.pattern-".concat(g_currentPattern)).attr("opacity", 1);
  updateDescription(action, step); // disabled button history

  disabledButton("history");
  g_isDisabledBtn1[g_currentPattern] = true;
  $(".buttons-1").removeClass("btn-pointer");
  g_cup1.fillWaterTo(action[0] + 3 * (pattern - 1), action[1] + 3 * (pattern - 1), action[2], function () {
    // change text
    $(".cup-".concat(action[0] + 3 * (pattern - 1), "-remain")).text(action[3] + CONFIG.UNIT);
    $(".cup-".concat(action[1] + 3 * (pattern - 1), "-remain")).text(action[4] + CONFIG.UNIT); // enabled history

    enabledButton("history");
    g_isDisabledBtn1[g_currentPattern] = false;
    $(".buttons-1").addClass("btn-pointer");
    g_currentStep++;
    patterns.current = g_currentStep; // change button

    if (g_currentStep >= patterns.totalStep) {
      hiddenButton("pause");
      disabledButton("next");
      g_isDisabledBtn3[g_currentPattern] = true;
      $(".buttons-3").removeClass("btn-pointer");
    } else {
      hiddenButton("pause");
      enabledButton("next");
    }
  });
}

var g_cup1;
var g_cup2;
var g_cup3;
var g_jar = {};
$(".pattern-1, .pattern-2").hide();
$(".pattern-".concat(g_currentPattern)).show();
$(document).ready(function () {
  setTimeout(function () {
    $("#svg_root").show();
  }, 200);
  loadStaticSVG();
  loadConfig();
  initDragEvent();
  init();
  console.log("AAA");
  Draw.init(); // initShapes();

  if (!g_isShowLog) $("#text-log").css("opacity", 0); // buttons-1 history

  $(".history-buttons").on("mousedown", function () {
    if (g_isDisabledBtn1[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-history",
      sid: ".pattern-".concat(g_currentPattern, " .history-buttons")
    };
    activeButton("history");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .history-buttons"), true);
  }); // buttons-2 back

  $(".back-buttons").on("mousedown", function () {
    if (g_isDisabledBtn2[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-back",
      sid: ".pattern-".concat(g_currentPattern, " .back-buttons")
    };
    activeButton("back");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .back-buttons"), true);
    $(".play-step-description.pattern-".concat(g_currentPattern)).attr("opacity", 0);
  }); // buttons-3 play

  $(".play-buttons").on("mousedown", function () {
    if (g_isDisabledBtn3[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-play",
      sid: ".pattern-".concat(g_currentPattern, " .play-buttons")
    };
    g_isChanged = true;
    enabledButton("reload");
    activeButton("play");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .play-buttons"), true);
  }); // buttons-3 pause

  $(".pause-buttons").on("mousedown", function () {
    if (g_isDisabledBtn3[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-pause",
      sid: ".pattern-".concat(g_currentPattern, " .pause-buttons")
    };
    activeButton("pause");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .pause-buttons"), true);
  }); // buttons-3 resume

  $(".resume-buttons").on("mousedown", function () {
    if (g_isDisabledBtn3[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-resume",
      sid: ".pattern-".concat(g_currentPattern, " .resume-buttons")
    };
    activeButton("resume");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .resume-buttons"), true);
  }); // buttons-3 next

  $(".next-buttons").on("mousedown", function () {
    if (g_isDisabledBtn3[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-next",
      sid: ".pattern-".concat(g_currentPattern, " .next-buttons")
    };
    activeButton("next");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .next-buttons"), true);
  }); // buttons-4 reload

  $(".reload-buttons").on("mousedown", function () {
    if (g_isDisabledBtn4[g_currentPattern] || g_isAnimatingButton) return;
    g_selectedButton = {
      name: "btn-reload",
      sid: ".pattern-".concat(g_currentPattern, " .reload-buttons")
    };
    activeButton("reload");
    animateButtonEffect(".pattern-".concat(g_currentPattern, " .reload-buttons"), true);
    $(".play-step-description.pattern-".concat(g_currentPattern)).attr("opacity", 0);
  }); // radio pattern 1

  $(".radio-1").on("mousedown", function () {
    showElement(".radio-1 .active", true);
    showElement(".radio-2 .active", false); // hiddenButton("pause", true);
    // hiddenButton("resume", true);

    if (g_isPlayingAnimate[g_currentPattern]) {
      g_shape.stopAnimate();
      hiddenButton("pause");
      showPatternButton(".pause-buttons", false);
      showPatternButton(".resume-buttons", true);
      enabledButton("resume");
    }

    g_currentPattern = 1;
    $(".pattern-1, .pattern-2").hide();
    $(".pattern-".concat(g_currentPattern)).show();
    g_cup1 = g_jar["cup-1"];
    g_cup2 = g_jar["cup-2"];
    g_cup3 = g_jar["cup-3"];
    g_currentStep = CONFIG.PATTERN_1.current; // const realStep = g_currentStep == CONFIG.PATTERN_1.totalStep ? g_currentStep - 1 : g_currentStep;
    // const action = CONFIG.PATTERN_1.steps[realStep];
    // updateDescription(action, realStep);
  }); // radio pattern 2

  $(".radio-2").on("mousedown", function () {
    showElement(".radio-1 .active", false);
    showElement(".radio-2 .active", true); // hiddenButton("pause", true);
    // hiddenButton("resume", true);

    if (g_isPlayingAnimate[g_currentPattern]) {
      g_shape.stopAnimate();
      hiddenButton("pause");
      showPatternButton(".pause-buttons", false);
      showPatternButton(".resume-buttons", true);
      enabledButton("resume");
    } // setTimeout(() => {
    //     enabledButton("resume");
    // }, 110);


    g_currentPattern = 2;
    $(".pattern-1, .pattern-2").hide();
    $(".pattern-".concat(g_currentPattern)).show();
    g_cup1 = g_jar["cup-4"];
    g_cup2 = g_jar["cup-5"];
    g_cup3 = g_jar["cup-6"];
    g_currentStep = CONFIG.PATTERN_2.current; // const realStep = g_currentStep == CONFIG.PATTERN_2.totalStep ? g_currentStep - 1 : g_currentStep;
    // const action = CONFIG.PATTERN_2.steps[realStep];
    // updateDescription(action, realStep);
  }); // document mouse up

  $(document).on("mouseup", function () {
    if (!g_selectedButton) return;
    g_isAnimatingButton = false;
    var _g_selectedButton = g_selectedButton,
        sid = _g_selectedButton.sid;

    switch (g_selectedButton.name) {
      case "btn-history":
        if (g_isAnimatingButton) return;
        animateButtonEffect(sid, false, function () {
          enabledButton("history");
        });
        showHistory(g_currentPattern === 2 ? ".pattern-02-history" : ".pattern-01-history", g_currentStep);
        break;

      case "btn-back":
        if (g_isAnimatingButton) return;
        if (g_currentStep > 0) g_currentStep--;
        if (g_currentStep < 0) g_currentStep = 0;
        backToStep(g_currentStep);
        animateButtonEffect(sid, false, function () {});
        break;

      case "btn-play":
        if (g_isAnimatingButton) return;
        playStep(g_currentStep);
        animateButtonEffect(sid, false, function () {
          // change play -> pause
          hiddenButton("play");
          showPatternButton(".play-buttons", false);
          showPatternButton(".pause-buttons", true);
          enabledButton("pause"); // enabled all button
          // enabledButton("history");
          // $(".buttons-1").addClass("btn-pointer");
          // g_isDisabledBtn1[g_currentPattern] = false;

          enabledButton("back");
          $(".buttons-2").addClass("btn-pointer");
          g_isDisabledBtn2[g_currentPattern] = false;
          enabledButton("reload");
          $(".buttons-4").addClass("btn-pointer");
          g_isDisabledBtn4[g_currentPattern] = false;
        });
        break;

      case "btn-pause":
        g_shape.stopAnimate();
        if (g_isAnimatingButton) return;
        animateButtonEffect(sid, false, function () {
          // change pause -> resume
          hiddenButton("pause");
          showPatternButton(".pause-buttons", false);
          showPatternButton(".resume-buttons", true);
          enabledButton("resume");
        });
        break;

      case "btn-resume":
        g_shape.continueAnimate();
        if (g_isAnimatingButton) return; // playStep(g_currentStep);

        animateButtonEffect(sid, false, function () {
          // change resume -> pause
          hiddenButton("resume");
          showPatternButton(".resume-buttons", false);
          showPatternButton(".pause-buttons", true);
          enabledButton("pause");
        });
        break;

      case "btn-next":
        if (g_isAnimatingButton) return;
        playStep(g_currentStep);
        animateButtonEffect(sid, false, function () {
          // change resume -> pause
          hiddenButton("next");
          showPatternButton(".next-buttons", false);
          showPatternButton(".pause-buttons", true);
          enabledButton("pause");
        });
        break;

      case "btn-reload":
        if (g_isAnimatingButton) return;
        g_isChanged = false;
        g_isDisabledBtn3[g_currentPattern] = false;
        g_currentStep = 0;
        backToStep(g_currentStep);
        animateButtonEffect(sid, false, function () {
          // disabled and reload history
          disabledButton("history");
          $(".buttons-1").removeClass("btn-pointer");
          g_isDisabledBtn1[g_currentPattern] = true; // disabled btn back

          disabledButton("back");
          $(".buttons-2").removeClass("btn-pointer");
          g_isDisabledBtn2[g_currentPattern] = true; // change buttons 3 to play

          hiddenButton("next");
          hiddenButton("resume");
          hiddenButton("pause");
          enabledButton("play");
          $(".buttons-3").addClass("btn-pointer"); // disabled btn reload

          disabledButton("reload");
          $(".buttons-4").removeClass("btn-pointer");
          g_isDisabledBtn4[g_currentPattern] = true;
        });
        break;

      default:
        break;
    }

    g_selectedButton = null;
  });
  var initAmount = [10, 0, 0];
  var cup1 = new Jar(new Point3D(0, 0, 0), Draw.setting.grid, "cup-1", 10, initAmount[0], 1); // cup1.isShowPoint = true;
  // cup1.isShowEdge = true;

  cup1.initDom(Draw.shapeGroup);
  cup1.render();
  var cup2 = new Jar(new Point3D(0, 0, 0), Draw.setting.grid, "cup-2", 7, initAmount[1], 1); // cup2.isShowPoint = true;
  // cup2.isShowEdge = true;

  cup2.initDom(Draw.shapeGroup);
  cup2.render();
  var cup3 = new Jar(new Point3D(0, 0, 0), Draw.setting.grid, "cup-3", 3 + 11 / 23, initAmount[2], 1); // cup3.isShowPoint = true;
  // cup3.isShowEdge = true;

  cup3.initDom(Draw.shapeGroup);
  cup3.render();
  var cup4 = new Jar(new Point3D(0, 0, 0), Draw.setting.grid, "cup-4", 10, initAmount[0], 2);
  cup4.initDom(Draw.shapeGroup);
  cup4.render();
  var cup5 = new Jar(new Point3D(0, 0, 0), Draw.setting.grid, "cup-5", 7, initAmount[1], 2);
  cup5.initDom(Draw.shapeGroup);
  cup5.render();
  var cup6 = new Jar(new Point3D(0, 0, 0), Draw.setting.grid, "cup-6", 3 + 11 / 23, initAmount[2], 2);
  cup6.initDom(Draw.shapeGroup);
  cup6.render();
  g_shape = cup3;
  g_cup1 = cup1;
  g_cup2 = cup2;
  g_cup3 = cup3;
  g_jar["cup-1"] = cup1;
  g_jar["cup-2"] = cup2;
  g_jar["cup-3"] = cup3;
  g_jar["cup-4"] = cup4;
  g_jar["cup-5"] = cup5;
  g_jar["cup-6"] = cup6;
  showElement(".cup-curves .cup-1", false);
  showElement(".cup-curves .cup-2", false);
  showElement(".cup-curves .cup-3", false);
  showElement(".cup-curves .cup-4", false);
  showElement(".cup-curves .cup-5", false);
  showElement(".cup-curves .cup-6", false);
});