"use strict";

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

var SVGLib = {
  createTag: function createTag(tag, attrs) {
    var obj = document.createElementNS(CONST.SVG.NAMESPACE, tag);
    $.map(Object.keys(attrs), function (key) {
      $(obj).attr(key, attrs[key]);
    });
    return obj;
  },
  getStrMatrix: function getStrMatrix(a, b, c, d, e, f) {
    return "matrix(".concat([a, b, c, d, e, f].map(function (x) {
      return x || 0;
    }).join(","), ")");
  },
  getLinePath: function getLinePath(o, p1, p2, grid) {
    var d = ["M", roundDecimal2((o.x + p1.x) * grid), roundDecimal2((o.y + p1.y) * grid), "L", roundDecimal2((o.x + p2.x) * grid), roundDecimal2((o.y + p2.y) * grid)].join(" ");
    return d;
  },
  drawLine: function drawLine(o, p1, p2, grid, lineStyle, id, strClass) {
    var attrs = Object.assign(lineStyle, {
      d: this.getLinePath(o, p1, p2, grid),
      id: id,
      class: "".concat(strClass, " ").concat(id)
    });
    var line = this.createTag("path", attrs);
    return line;
  },
  getPointPos: function getPointPos(o, p, grid) {
    var cx = roundDecimal2((o.x + p.x) * grid);
    var cy = roundDecimal2((o.y + p.y) * grid);
    return {
      cx: cx,
      cy: cy
    };
  },
  drawPoint: function drawPoint(o, p, grid, pointStyle, id) {
    var pointPos = this.getPointPos(o, p, grid);
    var attrs = Object.assign(pointStyle, {
      cx: pointPos.cx,
      cy: pointPos.cy,
      id: id,
      class: id
    });
    var point = this.createTag("circle", attrs);
    return point;
  },
  getFacePath: function getFacePath(o, faceVertices, grid) {
    var d = "".concat($.map(faceVertices, function (v, id) {
      return [id == 0 ? "M" : "L", roundDecimal2((o.x + v.x) * grid), roundDecimal2((o.y + v.y) * grid)].join(" ");
    }).join(" "), "z");
    return d;
  },
  getFaceStyle: function getFaceStyle(faceVertices, type) {
    var fill;
    var opacity;
    var minOpacity = 0.2;
    var middleOpacity = 0.5;
    var maxOpacity = 0.8;
    var u = faceVertices[0].sub(faceVertices[1]);
    var v = faceVertices[0].sub(faceVertices[2]);
    var normVector = u.crossProduct(v);
    var w = new Point3D(0, 0, 1);
    var color1 = type == CONST.SHAPE_TYPES.CUBE_CORE ? "#6DB8EB" : "#D8E9F0";
    var color2 = type == CONST.SHAPE_TYPES.CUBE_CORE ? "#6DB8EB" : "#D8E9F0"; // 0 to 180

    var alpha = MathLib.angleBetweenVectors(new Point3D(0, 0, 0), normVector, w); // alpha = 180 - alpha;
    // if (alpha > 90)
    //     alpha = 180 - alpha;

    if (alpha < 90) {
      // [middle, max]
      fill = color1;
      opacity = middleOpacity + (maxOpacity - middleOpacity) * (1 - alpha / 90);
    } else {
      // [min, middle]
      fill = color2;
      opacity = middleOpacity - (alpha / 90 - 1) * (middleOpacity - minOpacity);
    }

    if (type != CONST.SHAPE_TYPES.CUBE_CORE) opacity = 0.7;
    return {
      fill: fill,
      opacity: roundDecimal2(opacity)
    };
  },
  drawFace: function drawFace(o, faceVertices, grid, faceStyle, id, cssClass) {
    var attrs = Object.assign(faceStyle, {
      d: this.getFacePath(o, faceVertices, grid),
      id: id,
      class: id
    });

    if (cssClass) {
      attrs.class = "".concat(attrs.class || "", " ").concat(cssClass);
    }

    var face = this.createTag("path", attrs);
    return face;
  },
  drawText: function drawText(o, x, y, text, grid, textStyle, id) {
    var attrs = Object.assign(textStyle, {
      x: roundDecimal2((o.x + x) * grid),
      y: roundDecimal2((o.y + y) * grid),
      id: id,
      class: id
    });
    var svgText = this.createTag("text", attrs);
    svgText.textContent = text;
    return svgText;
  },
  updateStyle: function updateStyle(el, styles) {
    $.map(Object.keys(styles), function (key) {
      $(el).attr(key, styles[key]);
    });
  },
  getTranslate: function getTranslate(el) {
    var matrix = $(el).attr("transform");

    if (matrix === "none") {
      matrix = $(el).css("transform");
    }

    matrix = matrix.replace(/[^0-9\s\-.,]/g, "").split(/[\s,]/).map(function (m) {
      return Number(m);
    });

    if (matrix.length === 1) {
      return {
        top: 0,
        left: 0
      };
    }

    var x = matrix[12] || matrix[4] || matrix[0];
    var y = matrix[13] || matrix[5] || matrix[1];
    return {
      left: x,
      top: y
    };
  },
  // https://stackoverflow.com/questions/5737975/circle-drawing-with-svgs-arc-path/10477334#10477334
  getPathCircle: function getPathCircle(cx, cy, r) {
    // prettier-ignore
    return ["M ".concat(cx, " ").concat(cy), "m -".concat(r, ", 0"), "a ".concat(r, ",").concat(r, " 0 1,0 (").concat(r, " * 2),0"), "a ".concat(r, ",").concat(r, " 0 1,0 -(").concat(r, " * 2),0")].join('');
  },
  drawCircle: function drawCircle(o, cx, cy, r, grid, circleStyle, id, className) {
    var attrs = Object.assign(circleStyle, {
      cx: roundDecimal2((o.x + cx) * grid),
      cy: roundDecimal2((o.y + cy) * grid),
      r: roundDecimal2(r * grid),
      id: id,
      class: "".concat(className, " ").concat(id)
    });
    var svgCircle = this.createTag("circle", attrs);
    return svgCircle;
  },
  getEllipsePointForAngle: function getEllipsePointForAngle(cx, cy, rx, ry, phi, theta) {
    var abs = Math.abs,
        sin = Math.sin,
        cos = Math.cos;
    var M = abs(rx) * cos(theta);
    var N = abs(ry) * sin(theta);
    return [cx + cos(phi) * M - sin(phi) * N, cy + sin(phi) * M + cos(phi) * N];
  },
  getEndpointParameters: function getEndpointParameters(cx, cy, rx, ry, phi, theta, dTheta) {
    var _SVGLib$getEllipsePoi = SVGLib.getEllipsePointForAngle(cx, cy, rx, ry, phi, theta),
        _SVGLib$getEllipsePoi2 = _slicedToArray(_SVGLib$getEllipsePoi, 2),
        x1 = _SVGLib$getEllipsePoi2[0],
        y1 = _SVGLib$getEllipsePoi2[1];

    var _SVGLib$getEllipsePoi3 = SVGLib.getEllipsePointForAngle(cx, cy, rx, ry, phi, theta + dTheta),
        _SVGLib$getEllipsePoi4 = _slicedToArray(_SVGLib$getEllipsePoi3, 2),
        x2 = _SVGLib$getEllipsePoi4[0],
        y2 = _SVGLib$getEllipsePoi4[1];

    var fa = Math.abs(dTheta) > Math.PI ? 1 : 0;
    var fs = dTheta > 0 ? 1 : 0;
    var d = ["M", x1, y1, "A", rx, ry, 0, fa, fs, x2, y2].join(" ");
    console.log("getEndpointParameters", d);
    return d;
  },
  drawEllipsePath: function drawEllipsePath(o, cx, cy, rx, ry, phi, theta, dTheta, grid, circleStyle, id, className) {
    var d = SVGLib.getEndpointParameters(cx, cy, rx, ry, phi, theta, dTheta);
    var attrs = Object.assign(circleStyle, {
      d: d,
      id: id,
      class: "".concat(className, " ").concat(id)
    });
    var svgEllipse = this.createTag("path", attrs);
    return svgEllipse;
  }
};